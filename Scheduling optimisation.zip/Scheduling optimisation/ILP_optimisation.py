# -*- coding: utf-8 -*-
"""
Created on Sat May  8 14:36:10 2021

@author: Alex Luo
"""

import math as m
from random import randrange
import random as r
import heapq as hq
import queue as qu
import matplotlib.pyplot as plt
import numpy as np
import sys
import copy
from pulp import *
from gekko import GEKKO
from scipy.optimize import minimize
import scipy as sc
import timeit




#=====IMPORT DELIVERIES==============
delivery={}
with open('C:\\Users\\Alison Luo\\OneDrive - Imperial College London\\Documents\\Documents\\DE4\\Solo project\\Optimisation\\Code\\Scheduling optimisation\\optimised_journeys_94.txt','r') as file:    

    line = file.readlines()
    count = len(line)
    delivery_total=int(count/8)
    for delivery_no in range(int(delivery_total)):
        id_st=(line[(delivery_no*8)+1]).split()
        del_id=int(id_st[0])
        delivery[del_id]={}
        
        sg_line=(line[(delivery_no*8)+2]).split()
        delivery[del_id]['start']=(int(sg_line[0]),int(sg_line[1]))
        delivery[del_id]['goal']=(int(sg_line[2]),int(sg_line[3]))
        time_st=line[(delivery_no*8)+3].split()
        delivery[del_id]['time']=m.ceil(float((time_st[0]))*2)
        energy_st=line[(delivery_no*8)+4].split()
        delivery[del_id]['energy']=float(energy_st[0])*2
        distance_st=line[(delivery_no*8)+5].split()
        delivery[del_id]['distance']=float(distance_st[0])
        cost_st=line[(delivery_no*8)+6].split()
        delivery[del_id]['cost']=float(cost_st[0])
#=========IMPORT DELIVERIES======================

#=========VACCINATION DELIVERY SCALING============
total_vials=25000
vial_ratio=[0.6,0.3,0.1] 
villages=delivery_total
ref=0.7

vials=[0,0,0]
for x in range(len(vial_ratio)):
    vials[x]=total_vials*vial_ratio[x]
    
doses_ratio=[(vial_ratio[0])/2,(vial_ratio[1]),(vial_ratio[2])/2]

village_ratio=[0,0,0]
for vil in range(3):
    village_ratio[vil]=round((doses_ratio[vil]/sum(doses_ratio))*villages)

v_pvill=[0,0,0]
for x in range(len(vial_ratio)):
    if village_ratio[x]==0:
        v_pvill[x]=0
    else:
        v_pvill[x]=vials[x]/village_ratio[x]
    
N_of=round(village_ratio[0]*(1-ref))
N_on=round(village_ratio[0]*ref)
N_jf=round(village_ratio[1]*(1-ref))
N_jn=round(village_ratio[1]*ref) 
N_pf=round(village_ratio[2]*(1-ref)) 
N_pn=round(village_ratio[2]*ref)

N_cu=[N_of,N_of+N_on,N_of+N_on+N_jf,N_of+N_on+N_jf+N_jn,N_of+N_on+N_jf+N_jn+N_pf,N_of+N_on+N_jf+N_jn+N_pf+N_pn]

d_of=N_of*(v_pvill[0]/25)
d_on=N_on*(v_pvill[0]/12)
d_jf=N_jf*(v_pvill[1]/25)
d_jn=N_jn*(v_pvill[1]/12)
d_pf=N_pf*(v_pvill[2]/25)
d_pn=N_pn*(v_pvill[2]/12)

if N_of!=0:
    div_of=round(d_of/N_of)
else:
    div_of=0
if N_on!=0:
    div_on=round(d_on/N_on) 
else:
    div_on=0
if N_jf!=0:
    div_jf=round(d_jf/N_jf)
else:
    div_jf=0
if N_jn!=0:
    div_jn=round(d_jn/N_jn)
else:
    div_jn=0
if N_pf!=0:
    div_pf=round(d_pf/N_pf)
else:
    div_pf=0
if N_pn!=0:
    div_pn=round(d_pn/N_pn)
else:
    div_pn=0

#EXTRA DELIVERIES
expv=10
N_ex=expv*villages
delivery_extra={}

daily_lim={}
for d in delivery.keys():
    daily_lim[delivery[d]['goal']]=int(0)
    

#========DETERMINISTIC RANDOM SETS================
ranP_d={}
r.seed(9001)
random_PTL = [r.randint(1,3) for i in range(1,2501)]
for i in range(len(random_PTL)):
    ranP_d[i+1]=random_PTL[i]
    
ranP_ex={}
r.seed(9001)
random_PTL = [r.randint(4,18) for i in range(1,71)]
for i in range(len(random_PTL)):
    ranP_ex[i+1]=random_PTL[i]
    
#=======DETERMINISTIC RANDOM SETS================

#=========VACCINATION DELIVERY SCALING============

count_d=0
for deliv in delivery.keys():
    delivery[deliv]['Priority']=ranP_d[deliv]
    if count_d<(N_cu[0]):
        delivery[deliv]['Refrigerator']=1
        delivery[deliv]['Vaccine type']=str('oxford')
        delivery[deliv]['Vaccine priority']=int(6)
        delivery[deliv]['dup']=1
        count_d+=1
    elif count_d<(N_cu[1]):
        delivery[deliv]['Refrigerator']=0
        delivery[deliv]['Vaccine type']=str('oxford')
        delivery[deliv]['Vaccine priority']=int(4)
        delivery[deliv]['dup']=2
        count_d+=1
    elif count_d<(N_cu[2]):
        delivery[deliv]['Refrigerator']=1
        delivery[deliv]['Vaccine type']=str('jahnssen')
        delivery[deliv]['Vaccine priority']=int(6)
        delivery[deliv]['dup']=3
        count_d+=1
    elif count_d<(N_cu[3]):
        delivery[deliv]['Refrigerator']=0
        delivery[deliv]['Vaccine type']=str('jahnssen')
        delivery[deliv]['Vaccine priority']=int(5)
        delivery[deliv]['dup']=4
        count_d+=1
    elif count_d<(N_cu[4]):
        delivery[deliv]['Refrigerator']=1
        delivery[deliv]['Vaccine type']=str('pfizer')
        delivery[deliv]['Vaccine priority']=int(6)
        delivery[deliv]['dup']=5
        count_d+=1
    elif count_d<=(N_cu[5]):
        delivery[deliv]['Refrigerator']=0
        delivery[deliv]['Vaccine type']=str('pfizer')
        delivery[deliv]['Vaccine priority']=int(4)
        delivery[deliv]['dup']=6
        count_d+=1

delivery_temp={}
for deliv in delivery.keys():
    if delivery[deliv]['dup']==int(1):
        for multiply in range(div_of):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(m.floor(expv)):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(2):
        for multiply in range(div_on):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(m.floor(expv)):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(3):
        for multiply in range(div_jf):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(m.floor(expv)):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(4):
        for multiply in range(div_jn):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(m.floor(expv)):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(5):
        for multiply in range(div_pf):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(m.floor(expv)):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(6):
        for multiply in range(div_pn):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(m.floor(expv)):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])

delivery.update(delivery_temp)

delivexc=0
for delivex in delivery_extra.keys():
    delivexc+=1
    delivery_extra[delivex]['time']=30
    delivery_extra[delivex]['energy']=20
    delivery_extra[delivex]['dup']=int(0)
    delivery[delivex]['time']=copy.deepcopy(30)
    delivery[delivex]['energy']=copy.deepcopy(20)
    delivery[delivex]['dup']=int(0)


#=====OPERATIONS VARIABLES===========
t_prep=15
t_unpack=15
c_rate_h=22.85
c_rate_s=16.32
p_margin=5 
day=1
day_len=540
#=====OPERATIONS VARIABLES===========



#=======FUNCTIONS==============
def time_to_charge(rate,percentage):
    Ah=28.935*(percentage/100)
    time=m.ceil((Ah/rate)*60)
    return time

def amount_charged(rate,time_passed):
    SOC_up=(((time_passed/60)*rate)/28.935)*100
    return SOC_up

def charger_free(CH,B,min_time,end_time,B_number,PQ_tocharge,day):
    busy=1
    for charger in CH.keys():
        busy=0
        for timestamp in CH[charger][day]:
            if ((min_time> timestamp[1] and min_time<timestamp[2]) or (end_time> timestamp[1] and end_time<timestamp[2])):
                busy=1
                break
        if busy==0:
            free_charger=charger
            break
    if busy==1:
        B[B_number]['id']=('idle not charged', min_time, None)
        hq.heappush(PQ_tocharge, (B[B_number]['SOC'],B_number))
        free_charger=None
        
    return free_charger,B, PQ_tocharge 

def charger_free_noq(CH,B,min_time,end_time,B_number,day):
    busy=1
    for charger in CH.keys():
        busy=0
        for timestamp in CH[charger][day]:
            if ((min_time> timestamp[1] and min_time<timestamp[2]) or (end_time> timestamp[1] and end_time<timestamp[2])):
                busy=1
                break
        if busy==0:
            free_charger=charger
            break
    if busy==1:
        free_charger=None
    return free_charger


def lowest_SOC(B):
    current_low=90
    lowest_charging=None
    for battery in B:
        if B[battery]['id'][0]=='charging':
            inspecting=B[battery]['SOC']
            if inspecting<current_low:
                current_low=inspecting
                lowest_charging=battery
    return lowest_charging

def charge_batt(CH,B,min_time,end_time,B_number,C_number,day):
    CH[C_number][day].append((B_number,min_time,end_time))
    B[B_number]['id']=('charging',min_time,end_time)
    B[B_number]['CP']=min_time
    B[B_number]['charger']=C_number
    return CH,B


def swap_charging_with_idle(B,CH,B_idle,min_time,end_time,rate,PQ_tocharge,day):
    lowest_battery=lowest_SOC(B)
    
    time_passed=min_time-B[lowest_battery]['id'][1]
    lowest_charger=B[lowest_battery]['charger']
    for timestamp in CH[lowest_charger][day]:
        if timestamp[0]==lowest_battery and timestamp[1]==B[lowest_battery]['id'][1]:
            position=CH[lowest_charger][day].index(timestamp)
            CH[lowest_charger][day][position]=(lowest_battery,B[lowest_battery]['id'][1],time_passed+timestamp[1])
    SOC_partial=amount_charged(rate,time_passed)
    B[lowest_battery]['SOC']=B[lowest_battery]['SOC']+SOC_partial
    B[lowest_battery]['id']=('idle not charged',min_time,None)
    B[lowest_battery]['charger']=None
    hq.heappush(PQ_tocharge,(B[lowest_battery]['SOC'],lowest_battery))
    CH,B=charge_batt(CH,B,min_time,end_time,B_idle,lowest_charger,day)
    
    return CH,B,PQ_tocharge

    
def maximum_heap(PQ):
    max_hq=[]
    for n_inv in range(len(PQ)):
        hq.heappush(max_hq, ((PQ[n_inv][0])*-1,PQ[n_inv][1]))
    max_value=(hq.heappop(max_hq))
    max_value=(-1*max_value[0],max_value[1])
    updated=[]
    for n_inv in range(len(max_hq)):
        hq.heappush(updated, ((max_hq[n_inv][0])*-1,max_hq[n_inv][1]))
    return max_value,updated

def charge_next_qwaiting(CH,B,PQ_tocharge,rate,min_time,batt_removed,day):
    next_battery, PQ_tocharge=maximum_heap(PQ_tocharge)
    percentage=(90-next_battery[0])
    end_time=(time_to_charge(rate, percentage))+min_time
    CH,B=charge_batt(CH,B,min_time,end_time,next_battery[1],B[batt_removed]['charger'],day)
    return CH,B,PQ_tocharge

#=======FUNCTIONS==============    

    
#=====SCHEDULING FUNCTION===============

def schedule(N_dr,N_b,N_ch):
    day=1
    #=======PRIORITY QUEUES==============
    PQ_d = [] 
    for deliv in delivery.keys():
        if deliv not in delivery_extra:
            hq.heappush(PQ_d, ((delivery[deliv]['Priority']*delivery[deliv]['Vaccine priority']), deliv))

    PQ_ex=[]
    for delivex in delivery_extra.keys():
        hq.heappush(PQ_ex,(5,delivex))
    
    #======EXTRA DELIVERY DAY ONE
    for extra in range(m.floor(N_ex/30)):
        if len(PQ_ex)!=0:
            next_ex=hq.heappop(PQ_ex)
            next_ex=(ranP_ex[extra+1],next_ex[1])
            hq.heappush(PQ_d,(next_ex))    
    #======EXTRA DELIVERY DAY ONE
    
    PQ_batt = []
    B_small=[]
    PQ_tocharge = []
    
    #=======PRIORITY QUEUES==============
    #----DRONES AND DRONES MINIMUM TIME-------
    DR={}
    t_drocc={}
    for drone in range(N_dr):
        DR[drone+1]={}
        DR[drone+1][day]=[] 
        DR[drone+1]['plot']=[]
        t_drocc[drone+1]=int(0)
    
    #----BATTERY--------------
    B={}
    
    for battery in range(N_b):
        B[battery+1]={}
        B[battery+1]['id']=('idle charged',None,None)
        B[battery+1]['SOC']=float(90)
        B[battery+1]['charger']=int()
        B[battery+1]['CP']=int()
        
    #----CHARGERS--------------
    CH={}
    
    for charger in range(N_ch):
        CH[charger+1]={}
        CH[charger+1][1]=[] 
        CH[charger+1]['plot']=[]
        
    #=====SETUP DRONES, BATTERIES, CHARGERS===============
    
    #======SINGLE DELIVERY SINGLE TL========
    PQ_tocharge = []
    PQ_late=[]
    PQ_lim=[]
    refleft=1
    tt_wait=0
    part_days=0
    no_del=0
    while PQ_d or refleft==1:
        #==MINIMUM TIME=====
        B_small=[]
        d_long=[]
        tl_current=min(t_drocc, key=t_drocc.get)
        min_time=t_drocc[tl_current]
        if min_time==1000:
            day=day+1
            for extra in range (m.floor(N_ex/30)):
                if len(PQ_ex)!=0:
                    next_ex=hq.heappop(PQ_ex)
                    next_ex=(ranP_ex[extra+1],next_ex[1])
                    hq.heappush(PQ_d,(next_ex))
                else:
                    break
            for times in t_drocc.keys():
                t_drocc[times]=int(0)
            for limits in daily_lim.keys():
                daily_lim[limits]=0
            for battery in B.keys():
                B[battery]['id']=('idle charged',None,None)
                B[battery]['SOC']=100
                B[battery]['charger']=None
                B[battery]['CP']=int()
            for drone in DR.keys():
                DR[drone][day]=[]
            for charger in CH.keys():
                CH[charger][day]=[]
            PQ_tocharge=[]
            for late in PQ_late:
                hq.heappush(PQ_d,late)
            PQ_late=[]
            refleft=0
            continue
        elif len(PQ_d)==0 :
            if part_days==0:
                part_days=day
            for drone in DR.keys():
                t_drocc[drone]=1000
            refleft=1
            continue
        
        fulfilled=0
        all_smaller=0
        earl_up=0
        
        #==UPDATE FINISHED CHARGING BATTERIES=====
        for battery in B:
            if (B[battery]['id'][0]=='charging') and (min_time> B[battery]['id'][2]):
                 B[battery]['id']=('idle charged',B[battery]['id'][2],None)
                 B[battery]['SOC']=90
                 spare_CH=B[battery]['charger']
                 
                 if len(PQ_tocharge)!=0:

                     CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,min_time,battery,day)
                 else:
                     B[battery]['charger']=None
        #===UPDATE CHARGING SOC FOR MIN_TIME====
        for battery in B:
            if B[battery]['id'][0]=='charging'and (min_time< B[battery]['id'][2]):
                time_passed=min_time-(B[battery]['CP'])
                SOC_partial=amount_charged(c_rate_s,time_passed)
                B[battery]['CP']=min_time
                B[battery]['SOC']=B[battery]['SOC']+SOC_partial
        
        #===MAKE PQ_batt=========

        if len(DR[tl_current][day])!=0:
            p_deliv=DR[tl_current][day][-1]
            previous_battery=(B[p_deliv[1]]['SOC'],p_deliv[1])
            B[p_deliv[1]]['id']=('idle not charged',min_time,None)
        PQ_batt=[]
        for battery in B:
            if B[battery]['id'][0]=='idle charged'or B[battery]['id'][0]=='idle not charged'or B[battery]['id'][0]=='charging':
                hq.heappush(PQ_batt, (B[battery]['SOC'], battery))

        if len((PQ_batt))==0:
            pass
        #=====GET DELIVERY FOR MIN_TIME=====
        
        d_current=hq.heappop(PQ_d)
        deliv=d_current[1]
        
        #====END CONDITIONS AND DAY===============
        if delivery[deliv]['time']+min_time>(day_len-10):
            hq.heappush(PQ_d,d_current)
            d_length=len(PQ_d)
            for remdel in range(d_length):
                nbest=hq.heappop(PQ_d)
                if delivery[nbest[1]]['time']+min_time<(day_len-10):
                    d_current=nbest
                    deliv=nbest[1]

                    if len(PQ_late)!=0:
                        refleft=1
                    break
                else:
                    hq.heappush(d_long,nbest)
            for long in d_long:
                    hq.heappush(PQ_d,long)
            if len(d_long)==d_length:
                t_drocc[tl_current]=1000
                continue
        #=====COLD CHAIN CONSTRAINTS=========
        if (delivery[deliv]['dup']==2 and (delivery[deliv]['time']+min_time)>(day_len-300))or(delivery[deliv]['dup']==6 and (delivery[deliv]['time']+min_time>(day_len-300)))or(delivery[deliv]['dup']==4 and (delivery[deliv]['time']+min_time)>(day_len-180))or (daily_lim[delivery[deliv]['goal']]>=3 and delivery[deliv]['dup']!=0):
            hq.heappush(PQ_late,d_current)
            refleft=1
            if len(PQ_d)==0 : 
                if part_days==0:
                    part_days=day
                for drone in DR.keys():
                    t_drocc[drone]=1000
                refleft=1
            continue
        elif delivery[deliv]['dup']!=0:
            daily_lim[delivery[deliv]['goal']]+=1


        #======STANDARD FILLING==============
        most_charged, updatedPQ=maximum_heap(PQ_batt)
        if most_charged[0]<delivery[deliv]['energy']:
            all_smaller=1
        else:
        
            for batt_count in range(len(PQ_batt)):
                battery_pop=hq.heappop(PQ_batt)
                battery=battery_pop[1]
                smaller=delivery[deliv]['energy']+p_margin
                if (delivery[deliv]['energy']+p_margin)<=B[battery]['SOC']:
                    if min_time>0:
                        if previous_battery[1]!=battery:
                            percentage=(90-previous_battery[0])
                            end_time=(time_to_charge(c_rate_s, percentage))+min_time
                            free_charger,B,PQ_tocharge=charger_free(CH,B,min_time,end_time,previous_battery[1],PQ_tocharge,day)
                            if free_charger!=None:
                                CH,B=charge_batt(CH,B,min_time,end_time,previous_battery[1],free_charger,day)
                    if B[battery]['id'][0]=='charging':
                        highest_charger=B[battery]['charger']
                        for timestamp in CH[highest_charger][day]:
                            if timestamp[0]==battery and timestamp[1]==B[battery]['id'][1]:
                                position=CH[highest_charger][day].index(timestamp)
                                CH[highest_charger][day][position]=(battery,B[battery]['id'][1],min_time)
      
                        
                        if len(PQ_tocharge)!=0:
                            CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,min_time,battery,day)
                    if min_time==0:
                        B[battery]['id']=('use',min_time+t_prep,(min_time+delivery[deliv]['time']+t_prep))
                        DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep))
                        DR[tl_current][day].append((deliv,battery,min_time+t_prep,min_time+delivery[deliv]['time']+t_prep))
                        t_drocc[tl_current]=min_time+delivery[deliv]['time']+t_prep
                    else:
                        B[battery]['id']=('use',min_time+t_prep+t_unpack,(min_time+delivery[deliv]['time']+t_prep+t_unpack))
                        DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep+t_unpack))
                        DR[tl_current][day].append((deliv,battery,min_time+t_prep+t_unpack,min_time+delivery[deliv]['time']+t_prep+t_unpack))
                        
                        t_drocc[tl_current]=min_time+delivery[deliv]['time']+t_prep+t_unpack
                    no_del+=1
                    B[battery]['charger']=None #==
                    B[battery]['SOC']=B[battery]['SOC']-delivery[deliv]['energy']#==
                    fulfilled=1
                    break
                
                
                elif smaller>B[battery]['SOC']:
                    hq.heappush(B_small,battery_pop)
                    continue
    
        for small in B_small:
            hq.heappush(PQ_batt,small)
        B_small=[]
        if fulfilled==1:
            continue
        elif fulfilled==0 or all_smaller==1:
            no_del+=1
            highest_SOC,PQ_batt=maximum_heap(PQ_batt)
            #calculate time to wait
            SOC_req=((delivery[deliv]['energy']+p_margin)-highest_SOC[0])
            wait_time=time_to_charge(c_rate_s, SOC_req)
            fin_wait=min_time+wait_time
            if wait_time>t_prep+t_unpack:
                extra_wait=wait_time-(t_prep+t_unpack)
            else:
                extra_wait=0
            fin_deliver=min_time+(t_prep+t_unpack+extra_wait)+delivery[deliv]['time']
            #IF CURRENT BATTERY DIFFERENT TO LAST
            if min_time>0:
                if previous_battery[1]!=highest_SOC[1]:
                    percentage=(90-previous_battery[0])
                    end_time=(time_to_charge(c_rate_s, percentage))+min_time
                    free_charger,B,PQ_tocharge=charger_free(CH,B,min_time,end_time,previous_battery[1],PQ_tocharge,day)
                    if free_charger!=None:
                        CH,B=charge_batt(CH,B,min_time,end_time,previous_battery[1],free_charger,day)
            if B[highest_SOC[1]]['id'][0]=='charging':
    
                highest_charger=B[highest_SOC[1]]['charger']
                for timestamp in CH[highest_charger][day]:
                    if timestamp[0]==highest_SOC[1] and timestamp[1]==B[highest_SOC[1]]['id'][1]:
                        position=CH[highest_charger][day].index(timestamp)
                        CH[highest_charger][day][position]=(highest_SOC[1],B[highest_SOC[1]]['id'][1],fin_wait)
                B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req
                B[highest_SOC[1]]['id']=('charging',B[highest_SOC[1]]['id'][1],fin_wait)
                
                if len(PQ_tocharge)!=0:
                    CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,fin_wait,highest_SOC[1],day)
            elif B[highest_SOC[1]]['id'][0]=='idle not charged':
                
                free_charger=charger_free_noq(CH,B,min_time,fin_wait,highest_SOC[1],day)
                if free_charger!=None:
                    CH,B=charge_batt(CH,B,min_time,fin_wait,highest_SOC[1],free_charger,day)
                    B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req
                elif lowest_SOC(B)!=None:
                    CH,B, PQ_tocharge=swap_charging_with_idle(B,CH,highest_SOC[1],min_time,fin_wait,c_rate_s,PQ_tocharge,day) #**change
                    B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req#**change
                elif lowest_SOC(B)==None:
                    contender=(None,1000)
                    for charger in CH.keys():
                        for timestamp in CH[charger][day]:
                            if (min_time>= timestamp[1] and min_time<timestamp[2]) and timestamp[2]<contender[1]:
                                contender=(charger,timestamp[2])
                    earl_time=contender[1]
                    t_finalcharge=earl_time+wait_time
                    DR[tl_current][day].append(('Wait',None, min_time,t_finalcharge))
                    tt_wait+=(t_finalcharge-min_time)
                    if (t_finalcharge-min_time)<t_prep+t_unpack:
                        extra_wait=0
                    else:
                        extra_wait=(t_finalcharge-min_time)-(t_prep+t_unpack)
                    CH,B=charge_batt(CH, B, earl_time, t_finalcharge, highest_SOC[1], contender[0],day)
                    B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req
                    
                    B[highest_SOC[1]]['id']=('use',(min_time+t_prep+t_unpack+extra_wait),(min_time+t_prep+t_unpack+extra_wait)+delivery[deliv]['time'])
                    DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep+t_unpack))
                    DR[tl_current][day].append((deliv,highest_SOC[1],(min_time+t_prep+t_unpack+extra_wait),(min_time+t_prep+t_unpack+extra_wait)+delivery[deliv]['time']))
                    B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']-delivery[deliv]['energy']
                    
                    t_drocc[tl_current]=(min_time+t_prep+t_unpack+extra_wait)+delivery[deliv]['time']
                    if len(PQ_tocharge)!=0:
                        CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,(min_time+t_prep+t_unpack+extra_wait),highest_SOC[1],day)
                    else:
                        B[highest_SOC[1]]['charger']=None
                    earl_up=1
                    continue
                if len(PQ_tocharge)!=0:
                    CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,fin_wait,highest_SOC[1],day)#**change
            if earl_up!=1:
                B[highest_SOC[1]]['id']=('use',min_time+(t_prep+t_unpack+extra_wait),fin_deliver)
                DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep+t_unpack))
                DR[tl_current][day].append(('Wait',None,min_time,fin_wait))
                tt_wait+=(fin_wait-min_time)
                DR[tl_current][day].append((deliv,highest_SOC[1],min_time+(t_prep+t_unpack+extra_wait),fin_deliver))
                B[highest_SOC[1]]['SOC']=(B[highest_SOC[1]]['SOC']-delivery[deliv]['energy'])#==
                B[highest_SOC[1]]['charger']=None #**change #==
                t_drocc[tl_current]=fin_deliver
    
    tl_last=max(t_drocc, key=t_drocc.get)
    t_last=t_drocc[tl_last]
    final_wait=tt_wait/60
    total_time=(day*8)+m.floor(t_last/60)
    return total_time,final_wait
    


#=====ILP OPTIMISATION===============

#objective function
def f(x):
    rounded = np.around(x)
    x= rounded.astype(int)
    #making sure drone numbers are not larger than batteries
    if x[0]>x[1]:
        penal=50000
        return penal
    else:
        #calculate time and wait for a given drone item set
        time,wait=schedule(x[0],x[1],x[2])
        return (1500 * x[0]) + (625 *x[1]) +(100 * x[2]) +(20* wait)

def constraint(x):
    rounded = np.around(x)
    x= rounded.astype(int)
    if x[0]>x[1]:
        cons=-500
        return cons
    else:
        #making sure time is within monthly conditions
        time,wait=schedule(x[0],x[1],x[2])
        cons=239-time
        return cons

#Drone number less than battery number
def constraint1(x):
    rounded = np.around(x)
    x= rounded.astype(int)
    return x[1]-x[0]-1

#chargers are less than battery number
def constraint2(x):
    rounded = np.around(x)
    x= rounded.astype(int)
    return x[1]-x[2]

cons = [{"fun": constraint, "type": "ineq"},
        {"fun": constraint1, "type": "ineq"},
        {"fun": constraint2, "type": "ineq"}]

#setting start position
x0 = np.array([26,27,7])
bounds=[(5,50),(5,100),(1,20)]

comme = timeit.default_timer()

results=sc.optimize.minimize(f, x0,method='SLSQP', bounds=bounds,constraints=cons,options = {'ftol': 0.4, 'xtol': 0.4, 'eps':1 })
stop = timeit.default_timer()

#=====ILP OPTIMISATION===============
