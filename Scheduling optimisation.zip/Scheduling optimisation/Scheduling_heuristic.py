# -*- coding: utf-8 -*-
"""
Created on Sat May  8 14:36:10 2021

@author: Alex Luo
"""
#=====IMPORT MODULES=====
import math as m
import random as r
import heapq as hq
import matplotlib.pyplot as plt
import numpy as np
import copy


#====IMPORT DELIVERIES====
delivery={}
with open('C:\\Users\\Alison Luo\\OneDrive - Imperial College London\\Documents\\Documents\\DE4\\Solo project\\Optimisation\\Code\\Scheduling optimisation\\optimised_journeys_94.txt','r') as file:    
    line = file.readlines()
    count = len(line)
    delivery_total=int(count/8)
    #=====CREATE DELIVERIES BASED ON IMPORTED INFORMATION=====
    for delivery_no in range(int(delivery_total)):
        id_st=(line[(delivery_no*8)+1]).split()
        del_id=int(id_st[0])
        delivery[del_id]={}
        sg_line=(line[(delivery_no*8)+2]).split()
        delivery[del_id]['start']=(int(sg_line[0]),int(sg_line[1]))
        delivery[del_id]['goal']=(int(sg_line[2]),int(sg_line[3]))
        time_st=line[(delivery_no*8)+3].split()
        delivery[del_id]['time']=m.ceil(float((time_st[0]))*2)
        energy_st=line[(delivery_no*8)+4].split()
        delivery[del_id]['energy']=float(energy_st[0])*2
        distance_st=line[(delivery_no*8)+5].split()
        delivery[del_id]['distance']=float(distance_st[0])
        cost_st=line[(delivery_no*8)+6].split()
        delivery[del_id]['cost']=float(cost_st[0])
#====IMPORT DELIVERIES====

#=========VACCINATION DELIVERY SCALING============
total_vials=25000
vial_ratio=[0.6,0.3,0.1]
villages=delivery_total
ref=0.7

#number of vials of each vaccine type
vials=[0,0,0]
for x in range(len(vial_ratio)):
    vials[x]=total_vials*vial_ratio[x] 

#adjust for doses
doses_ratio=[(vial_ratio[0])/2,0.3,(vial_ratio[2])/2]   


village_ratio=[0,0,0]
for vil in range(3):
    village_ratio[vil]=round((doses_ratio[vil]/sum(doses_ratio))*villages) 


v_pvill=[0,0,0]
for x in range(len(vial_ratio)):
    if village_ratio[x]==0:
        v_pvill[x]=0
    else:
        v_pvill[x]=vials[x]/village_ratio[x]

#number of vaccine vials for delivery type
N_of=round(village_ratio[0]*(1-ref))   
N_on=round(village_ratio[0]*ref)   
N_jf=round(village_ratio[1]*(1-ref))
N_jn=round(village_ratio[1]*ref)  
N_pf=round(village_ratio[2]*(1-ref))
N_pn=round(village_ratio[2]*ref)

#cumulative array of villages for each journey type
N_cu=[N_of,N_of+N_on,N_of+N_on+N_jf,N_of+N_on+N_jf+N_jn,N_of+N_on+N_jf+N_jn+N_pf,N_of+N_on+N_jf+N_jn+N_pf+N_pn]

#number of deliveries to each delivery type
d_of=N_of*(v_pvill[0]/25)  
d_on=N_on*(v_pvill[0]/12)
d_jf=N_jf*(v_pvill[1]/25)
d_jn=N_jn*(v_pvill[1]/12)
d_pf=N_pf*(v_pvill[2]/25)
d_pn=N_pn*(v_pvill[2]/12)

#values to scale the previous 94 journeys
if N_of!=0: 
    div_of=round(d_of/N_of) 
else:
    div_of=0
if N_on!=0:
    div_on=round(d_on/N_on) 
else:
    div_on=0
if N_jf!=0:
    div_jf=round(d_jf/N_jf)
else:
    div_jf=0
if N_jn!=0:
    div_jn=round(d_jn/N_jn)
else:
    div_jn=0
if N_pf!=0:
    div_pf=round(d_pf/N_pf)
else:
    div_pf=0
if N_pn!=0:
    div_pn=round(d_pn/N_pn)
else:
    div_pn=0

#extra deliveries 
expv=10
N_ex=expv*villages
delivery_extra={}

#setting daily limit of each destination
daily_lim={}
for d in delivery.keys():
    daily_lim[delivery[d]['goal']]=int(0)
#=========VACCINATION DELIVERY SCALING============


#========DETERMINISTIC RANDOM SETS================
#random general priority
ranP_d={}
r.seed(9001)
random_PTL = [r.randint(1,3) for i in range(1,2501)]
for i in range(len(random_PTL)):
    ranP_d[i+1]=random_PTL[i]
    
#random total priority of extra deliveries
ranP_ex={}
r.seed(9001)
random_PTL = [r.randint(4,18) for i in range(1,71)]
for i in range(len(random_PTL)):
    ranP_ex[i+1]=random_PTL[i]
#=======DETERMINISTIC RANDOM SETS================

#=======ADDING DELIVERY DICTIONARY DETAILS================
count_d=0
for deliv in delivery.keys():
    delivery[deliv]['Priority']=ranP_d[deliv]#77
    if count_d<(N_cu[0]):
        delivery[deliv]['Refrigerator']=1
        delivery[deliv]['Vaccine type']=str('oxford')
        delivery[deliv]['Vaccine priority']=int(6)
        delivery[deliv]['dup']=1
        count_d+=1
    elif count_d<(N_cu[1]):
        delivery[deliv]['Refrigerator']=0
        delivery[deliv]['Vaccine type']=str('oxford')
        delivery[deliv]['Vaccine priority']=int(4)
        delivery[deliv]['dup']=2
        count_d+=1
    elif count_d<(N_cu[2]):
        delivery[deliv]['Refrigerator']=1
        delivery[deliv]['Vaccine type']=str('jahnssen')
        delivery[deliv]['Vaccine priority']=int(6)
        delivery[deliv]['dup']=3
        count_d+=1
    elif count_d<(N_cu[3]):
        delivery[deliv]['Refrigerator']=0
        delivery[deliv]['Vaccine type']=str('jahnssen')
        delivery[deliv]['Vaccine priority']=int(5)
        delivery[deliv]['dup']=4
        count_d+=1
    elif count_d<(N_cu[4]):
        delivery[deliv]['Refrigerator']=1
        delivery[deliv]['Vaccine type']=str('pfizer')
        delivery[deliv]['Vaccine priority']=int(6)
        delivery[deliv]['dup']=5
        count_d+=1
    elif count_d<=(N_cu[5]):
        delivery[deliv]['Refrigerator']=0
        delivery[deliv]['Vaccine type']=str('pfizer')
        delivery[deliv]['Vaccine priority']=int(4)
        delivery[deliv]['dup']=6
        count_d+=1

#scaling up for extra deliveries
delivery_temp={}
for deliv in delivery.keys():
    if delivery[deliv]['dup']==int(1):
        for multiply in range(div_of):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(expv):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(2):
        for multiply in range(div_on):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(expv):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(3):
        for multiply in range(div_jf):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(expv):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(4):
        for multiply in range(div_jn):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(expv):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(5):
        for multiply in range(div_pf):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(expv):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
    elif delivery[deliv]['dup']==int(6):
        for multiply in range(div_pn):
            delivery_total+=1
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])
        for extra in range(expv):
            delivery_total+=1
            delivery_extra[delivery_total]=copy.deepcopy(delivery[deliv])
            delivery_temp[delivery_total]=copy.deepcopy(delivery[deliv])

delivery.update(delivery_temp)

delivexc=0
for delivex in delivery_extra.keys():
    delivexc+=1
    delivery_extra[delivex]['time']=30
    delivery_extra[delivex]['energy']=20
    delivery_extra[delivex]['dup']=int(0)
    delivery[delivex]['time']=copy.deepcopy(30)
    delivery[delivex]['energy']=copy.deepcopy(20)
    delivery[delivex]['dup']=int(0)
#=======ADDING DELIVERY DICTIONARY DETAILS================

#=====OPERATIONS VARIABLES===========
t_prep=10 #time for preparing drone (mins)
t_unpack=10 #time for unpacking drone (mins)
c_rate_h=22.85 #high charge rate
c_rate_s=16.32 #standard charge rate
p_margin=5 #charging safety margin (%)
day_len=480 #length of day (mins)

#=====OPERATIONS VARIABLES===========

#=======PRIORITY QUEUES==============
#deliveries
PQ_d = []
for deliv in delivery.keys():
    if deliv not in delivery_extra:
        hq.heappush(PQ_d, ((delivery[deliv]['Priority']*delivery[deliv]['Vaccine priority']), deliv))

#extra deliveries
PQ_ex=[]
for delivex in delivery_extra.keys():
    hq.heappush(PQ_ex,(5,delivex))

#number of extra deliveries in a day
for extra in range(m.floor(N_ex/30)):
    if len(PQ_ex)!=0:
        next_ex=hq.heappop(PQ_ex)
        next_ex=(ranP_ex[extra+1],next_ex[1])
        hq.heappush(PQ_d,(next_ex))    

PQ_batt = []
B_small=[]
PQ_tocharge = []
#=======PRIORITY QUEUES==============

#=======FUNCTIONS==============

#calculates time to charge battery to a percentage
def time_to_charge(rate,percentage):
    Ah=28.935*(percentage/100)
    time=m.ceil((Ah/rate)*60)
    return time

#calculates the amount of charge gained for a time
def amount_charged(rate,time_passed):
    SOC_up=(((time_passed/60)*rate)/28.935)*100
    return SOC_up

#checks if there is a charger free
def charger_free(CH,B,min_time,end_time,B_number,PQ_tocharge,day):
    busy=1
    for charger in CH.keys():
        busy=0
        for timestamp in CH[charger][day]:
            if ((min_time> timestamp[1] and min_time<timestamp[2]) or (end_time> timestamp[1] and end_time<timestamp[2])):
                busy=1
                break
        if busy==0:
            free_charger=charger
            break
    if busy==1:
        B[B_number]['id']=('idle not charged', min_time, None)
        hq.heappush(PQ_tocharge, (B[B_number]['SOC'],B_number))
        free_charger=None
    return free_charger,B, PQ_tocharge

#checks if charger is free without affecting priority queue
def charger_free_noq(CH,B,min_time,end_time,B_number,day):
    busy=1
    for charger in CH.keys():
        
        busy=0
        for timestamp in CH[charger][day]:
            if ((min_time> timestamp[1] and min_time<timestamp[2]) or (end_time> timestamp[1] and end_time<timestamp[2])):
                busy=1
                break
        if busy==0:
            free_charger=charger
            break
        
    if busy==1:
        free_charger=None
    return free_charger

#finds the lowest battery SOC
def lowest_SOC(B):
    current_low=90
    lowest_charging=None
    for battery in B:
        if B[battery]['id'][0]=='charging':
            inspecting=B[battery]['SOC']
            if inspecting<current_low:
                current_low=inspecting
                lowest_charging=battery
    return lowest_charging

#Charges a battery for a given charger and time
def charge_batt(CH,B,min_time,end_time,B_number,C_number,day):
    CH[C_number][day].append((B_number,min_time,end_time))
    B[B_number]['id']=('charging',min_time,end_time)
    B[B_number]['CP']=min_time
    B[B_number]['charger']=C_number
    return CH,B

#swaps a charging and idle battery
def swap_charging_with_idle(B,CH,B_idle,min_time,end_time,rate,PQ_tocharge,day):
    lowest_battery=lowest_SOC(B)
    time_passed=min_time-B[lowest_battery]['id'][1]
    #UPDATE CHARGER OF REMOVING LOWEST SOC
    lowest_charger=B[lowest_battery]['charger']
    for timestamp in CH[lowest_charger][day]:
        if timestamp[0]==lowest_battery and timestamp[1]==B[lowest_battery]['id'][1]:
            position=CH[lowest_charger][day].index(timestamp)
            CH[lowest_charger][day][position]=(lowest_battery,B[lowest_battery]['id'][1],time_passed+timestamp[1])
    SOC_partial=amount_charged(rate,time_passed)
    B[lowest_battery]['SOC']=B[lowest_battery]['SOC']+SOC_partial
    B[lowest_battery]['id']=('idle not charged',min_time,None)
    B[lowest_battery]['charger']=None
    hq.heappush(PQ_tocharge,(B[lowest_battery]['SOC'],lowest_battery))
    
    CH,B=charge_batt(CH,B,min_time,end_time,B_idle,lowest_charger,day)
    
    return CH,B,PQ_tocharge
    
#finds the maximum value of a heap
def maximum_heap(PQ):
    max_hq=[]
    for n_inv in range(len(PQ)):
        hq.heappush(max_hq, ((PQ[n_inv][0])*-1,PQ[n_inv][1]))
    max_value=(hq.heappop(max_hq))
    max_value=(-1*max_value[0],max_value[1])
    updated=[]
    for n_inv in range(len(max_hq)):
        hq.heappush(updated, ((max_hq[n_inv][0])*-1,max_hq[n_inv][1]))
    return max_value,updated

#charges the next battery on PQ_tc heap
def charge_next_qwaiting(CH,B,PQ_tocharge,rate,min_time,batt_removed,day):
    next_battery, PQ_tocharge=maximum_heap(PQ_tocharge)
    percentage=(90-next_battery[0])
    end_time=(time_to_charge(rate, percentage))+min_time
    CH,B=charge_batt(CH,B,min_time,end_time,next_battery[1],B[batt_removed]['charger'],day)
    return CH,B,PQ_tocharge

#=======FUNCTIONS==============    

#=====SETUP DRONES, BATTERIES, CHARGERS===============
N_dr=18
N_b=26
N_ch=10
day=1

#----DRONES AND DRONES MINIMUM TIME-------
DR={}
t_drocc={}
finday={}

for drone in range(N_dr):
    DR[drone+1]={}
    DR[drone+1][day]=[]
    DR[drone+1]['plot']=[]
    t_drocc[drone+1]=int(0)
    finday[drone+1]={}

#----BATTERY--------------
B={}
for battery in range(N_b):
    B[battery+1]={}
    B[battery+1]['id']=('idle charged',None,None)
    B[battery+1]['SOC']=float(90)
    B[battery+1]['charger']=int()
    B[battery+1]['CP']=int()
    
#----CHARGERS--------------
CH={}
for charger in range(N_ch):
    CH[charger+1]={}
    CH[charger+1][1]=[]
    CH[charger+1]['plot']=[]
   
#=====SETUP DRONES, BATTERIES, CHARGERS===============

#======MAIN SCHEDULER========
#Resetting priority queues
PQ_tocharge = []
PQ_late=[]
PQ_lim=[]
refleft=1
tt_wait=0
part_days=0
no_del=0

#looping through deliveries to place
while PQ_d or refleft==1:
    B_small=[]
    d_long=[]
    #get minimum time occupied on drone timeline
    tl_current=min(t_drocc, key=t_drocc.get)
    min_time=t_drocc[tl_current]
    print('Start placing for day: '+str(day))
    #end of day conditions
    if min_time==1000:
        day=day+1
        #resetting extra deliveries for a new day
        for extra in range (m.floor(N_ex/30)):  #number of extra deliveries in a day
            if len(PQ_ex)!=0:
                next_ex=hq.heappop(PQ_ex)
                next_ex=(ranP_ex[extra+1],next_ex[1]) 
                hq.heappush(PQ_d,(next_ex))
            else:                
                for drone in DR.keys():
                    if finday[drone].get(day)==None:
                        finday[drone][day]=0
                break
        #reset timelines, batteries, drone and charger parameters 
        for times in t_drocc.keys():
            t_drocc[times]=int(0)
        for limits in daily_lim.keys():
            daily_lim[limits]=0
        for battery in B.keys():
            B[battery]['id']=('idle charged',None,None)
            B[battery]['SOC']=100
            B[battery]['charger']=None
            B[battery]['CP']=int()
        for drone in DR.keys():
            DR[drone][day]=[]
        for charger in CH.keys():
            CH[charger][day]=[]
        PQ_tocharge=[]
        #push back time restricted deliveries back into PQ_d
        for late in PQ_late:
            hq.heappush(PQ_d,late)
        PQ_late=[]
        refleft=0
        continue
    #when there are no deliveries left in PQ_d
    elif len(PQ_d)==0 :
        if part_days==0:
            part_days=day
        #blocking all timelines
        for drone in DR.keys():
            if finday[drone].get(day)==None:
                finday[drone][day]=t_drocc[drone]
                t_drocc[drone]=1000
            else:
                t_drocc[drone]=1000
        refleft=1
        continue
    fulfilled=0
    all_smaller=0
    earl_up=0
    
    #==UPDATE FINISHED CHARGING BATTERIES=====
    for battery in B:
        if (B[battery]['id'][0]=='charging') and (min_time> B[battery]['id'][2]):
             B[battery]['id']=('idle charged',B[battery]['id'][2],None)
             B[battery]['SOC']=90
             spare_CH=B[battery]['charger']
             
             if len(PQ_tocharge)!=0:
                 CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,min_time,battery,day)
             else:
                 B[battery]['charger']=None
             
    #===UPDATE CHARGING SOC FOR MIN_TIME====
    for battery in B:
        if B[battery]['id'][0]=='charging'and (min_time< B[battery]['id'][2]):
            time_passed=min_time-(B[battery]['CP'])

            SOC_partial=amount_charged(c_rate_s,time_passed)
            B[battery]['CP']=min_time

            B[battery]['SOC']=B[battery]['SOC']+SOC_partial
    
    #===MAKE PQ_batt=========
    
    #including the previous battery if there has been more than one event
    if len(DR[tl_current][day])!=0:
        p_deliv=DR[tl_current][day][-1]
        previous_battery=(B[p_deliv[1]]['SOC'],p_deliv[1])
        B[p_deliv[1]]['id']=('idle not charged',min_time,None)
    PQ_batt=[]
    #PQ_batt made of charging, idle charged and idle not charged batteries
    for battery in B:
        if B[battery]['id'][0]=='idle charged'or B[battery]['id'][0]=='idle not charged'or B[battery]['id'][0]=='charging':
            hq.heappush(PQ_batt, (B[battery]['SOC'], battery))
    if len((PQ_batt))==0:
        pass
    
    #pop a delivery
    d_current=hq.heappop(PQ_d)
    deliv=d_current[1]
    
    #====END CONDITIONS AND DAY===============
    if delivery[deliv]['time']+min_time>(day_len-10):
        hq.heappush(PQ_d,d_current)
        d_length=len(PQ_d)
        for remdel in range(d_length):
            nbest=hq.heappop(PQ_d)
            if delivery[nbest[1]]['time']+min_time<(day_len-10):
                d_current=nbest
                deliv=nbest[1]
                if len(PQ_late)!=0:
                    refleft=1
                break
            else:
                hq.heappush(d_long,nbest)
        for long in d_long:
                hq.heappush(PQ_d,long)
        if len(d_long)==d_length:
            finday[tl_current][day]=t_drocc[tl_current]
            t_drocc[tl_current]=1000
            continue
        
    #=====COLD CHAIN CONSTRAINTS=========
    if (delivery[deliv]['dup']==2 and (delivery[deliv]['time']+min_time)>(day_len-300))or(delivery[deliv]['dup']==6 and (delivery[deliv]['time']+min_time>(day_len-300)))or(delivery[deliv]['dup']==4 and (delivery[deliv]['time']+min_time)>(day_len-180))or (daily_lim[delivery[deliv]['goal']]>=3 and delivery[deliv]['dup']!=0):
        hq.heappush(PQ_late,d_current)
        refleft=1
        if len(PQ_d)==0 :
            if part_days==0:
                part_days=day
            for drone in DR.keys():
                if finday[drone].get(day)==None:
                    finday[drone][day]=t_drocc[drone]
                    t_drocc[drone]=1000
                else:
                    t_drocc[drone]=1000
            refleft=1
        continue
    elif delivery[deliv]['dup']!=0:
        daily_lim[delivery[deliv]['goal']]+=1
    
    #======STANDARD SCHEDULE FILLING==============
    
    most_charged, updatedPQ=maximum_heap(PQ_batt)
    if most_charged[0]<delivery[deliv]['energy']:
        all_smaller=1
    else:
        #looking for battery that is enough charge for the delivery
        for batt_count in range(len(PQ_batt)):
            battery_pop=hq.heappop(PQ_batt)
            battery=battery_pop[1]
            smaller=delivery[deliv]['energy']+p_margin
            if (delivery[deliv]['energy']+p_margin)<=B[battery]['SOC']:
                if min_time>0:
                    if previous_battery[1]!=battery:
                        percentage=(90-previous_battery[0])
                        end_time=(time_to_charge(c_rate_s, percentage))+min_time
                        free_charger,B,PQ_tocharge=charger_free(CH,B,min_time,end_time,previous_battery[1],PQ_tocharge,day)
                        if free_charger!=None:
                            CH,B=charge_batt(CH,B,min_time,end_time,previous_battery[1],free_charger,day)
                #replace charger with a new battery
                if B[battery]['id'][0]=='charging':
                    highest_charger=B[battery]['charger']
                    for timestamp in CH[highest_charger][day]:
                        if timestamp[0]==battery and timestamp[1]==B[battery]['id'][1]:
                            position=CH[highest_charger][day].index(timestamp)
                            CH[highest_charger][day][position]=(battery,B[battery]['id'][1],min_time)
  
                    
                    if len(PQ_tocharge)!=0:
                        CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,min_time,battery,day)
                #send out drone for delivery
                if min_time==0:
                    B[battery]['id']=('use',min_time+t_prep,(min_time+delivery[deliv]['time']+t_prep))
                    DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep))
                    DR[tl_current][day].append((deliv,battery,min_time+t_prep,min_time+delivery[deliv]['time']+t_prep))
                    t_drocc[tl_current]=min_time+delivery[deliv]['time']+t_prep
                else:
                    B[battery]['id']=('use',min_time+t_prep+t_unpack,(min_time+delivery[deliv]['time']+t_prep+t_unpack))
                    DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep+t_unpack))
                    DR[tl_current][day].append((deliv,battery,min_time+t_prep+t_unpack,min_time+delivery[deliv]['time']+t_prep+t_unpack))
                    t_drocc[tl_current]=min_time+delivery[deliv]['time']+t_prep+t_unpack
                no_del+=1
                B[battery]['charger']=None
                B[battery]['SOC']=B[battery]['SOC']-delivery[deliv]['energy']
                fulfilled=1
                if len(PQ_d)==0 and len(PQ_ex)==0 and len(PQ_late)==0:
                    for drone in DR.keys():
                        finday[drone][day]=t_drocc[drone]
                break
                        
            elif smaller>B[battery]['SOC']:
                hq.heappush(B_small,battery_pop)
                continue
    #not sufficient batteries are placed back into PQ_batt
    for small in B_small:
        hq.heappush(PQ_batt,small)
    B_small=[]
    if fulfilled==1:
        #MOVE ONTO NEXT TL_CURRENT AND d
        continue
    elif fulfilled==0 or all_smaller==1:
        no_del+=1
        #calculates the highest charging battery
        highest_SOC,PQ_batt=maximum_heap(PQ_batt)
        #calculate time to wait for this battery
        SOC_req=((delivery[deliv]['energy']+p_margin)-highest_SOC[0])
        wait_time=time_to_charge(c_rate_s, SOC_req)
        fin_wait=min_time+wait_time
        if wait_time>t_prep+t_unpack:
            extra_wait=wait_time-(t_prep+t_unpack)
        else:
            extra_wait=0
        fin_deliver=min_time+(t_prep+t_unpack+extra_wait)+delivery[deliv]['time']
        #IF CURRENT BATTERY DIFFERENT TO LAST
        if min_time>0:
            if previous_battery[1]!=highest_SOC[1]:
                percentage=(90-previous_battery[0])
                end_time=(time_to_charge(c_rate_s, percentage))+min_time
                free_charger,B,PQ_tocharge=charger_free(CH,B,min_time,end_time,previous_battery[1],PQ_tocharge,day)
                if free_charger!=None:
                    CH,B=charge_batt(CH,B,min_time,end_time,previous_battery[1],free_charger,day)
        #if highest charging is on a charger
        if B[highest_SOC[1]]['id'][0]=='charging':
            highest_charger=B[highest_SOC[1]]['charger']
            for timestamp in CH[highest_charger][day]:
                if timestamp[0]==highest_SOC[1] and timestamp[1]==B[highest_SOC[1]]['id'][1]:
                    position=CH[highest_charger][day].index(timestamp)
                    CH[highest_charger][day][position]=(highest_SOC[1],B[highest_SOC[1]]['id'][1],fin_wait)
            B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req
            B[highest_SOC[1]]['id']=('charging',B[highest_SOC[1]]['id'][1],fin_wait)
            
            if len(PQ_tocharge)!=0:
                CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,fin_wait,highest_SOC[1],day)
        #if highest charging is idle
        elif B[highest_SOC[1]]['id'][0]=='idle not charged':            
            free_charger=charger_free_noq(CH,B,min_time,fin_wait,highest_SOC[1],day)
            if free_charger!=None:
                CH,B=charge_batt(CH,B,min_time,fin_wait,highest_SOC[1],free_charger,day)
                B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req
            elif lowest_SOC(B)!=None:
                CH,B, PQ_tocharge=swap_charging_with_idle(B,CH,highest_SOC[1],min_time,fin_wait,c_rate_s,PQ_tocharge,day) 
                B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req#**change
            elif lowest_SOC(B)==None:
                #find earliest finishing charger
                contender=(None,1000)
                for charger in CH.keys():
                    for timestamp in CH[charger][day]:
                        if (min_time>= timestamp[1] and min_time<=timestamp[2]) and timestamp[2]<contender[1]:
                            contender=(charger,timestamp[2])
                earl_time=contender[1]
                t_finalcharge=earl_time+wait_time
                DR[tl_current][day].append(('Wait',None, min_time,t_finalcharge))
                #delay time
                tt_wait+=(t_finalcharge-min_time)
                if (t_finalcharge-min_time)<t_prep+t_unpack:
                    extra_wait=0
                elif contender[0]!=None:
                    extra_wait=(t_finalcharge-min_time)-(t_prep+t_unpack)
                CH,B=charge_batt(CH, B, earl_time, t_finalcharge, highest_SOC[1], contender[0],day)
                B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']+SOC_req
                
                B[highest_SOC[1]]['id']=('use',(min_time+t_prep+t_unpack+extra_wait),(min_time+t_prep+t_unpack+extra_wait)+delivery[deliv]['time'])
                DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep+t_unpack))
                DR[tl_current][day].append((deliv,highest_SOC[1],(min_time+t_prep+t_unpack+extra_wait),(min_time+t_prep+t_unpack+extra_wait)+delivery[deliv]['time']))
                B[highest_SOC[1]]['SOC']=B[highest_SOC[1]]['SOC']-delivery[deliv]['energy']
                
                t_drocc[tl_current]=(min_time+t_prep+t_unpack+extra_wait)+delivery[deliv]['time']
                if len(PQ_tocharge)!=0:
                    CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,(min_time+t_prep+t_unpack+extra_wait),highest_SOC[1],day)
                else:
                    B[highest_SOC[1]]['charger']=None
                
                earl_up=1
                if len(PQ_d)==0 and len(PQ_ex)==0 and len(PQ_late)==0: 
                    finday[tl_current][day]=t_drocc[tl_current]
                continue
            if len(PQ_tocharge)!=0:
                CH,B,PQ_tocharge=charge_next_qwaiting(CH,B,PQ_tocharge,c_rate_s,fin_wait,highest_SOC[1],day)
        #send out drone
        if earl_up!=1:
            B[highest_SOC[1]]['id']=('use',min_time+(t_prep+t_unpack+extra_wait),fin_deliver)
            DR[tl_current][day].append(('Prep',None,min_time,min_time+t_prep+t_unpack))
            DR[tl_current][day].append(('Wait',None,min_time,fin_wait))
            tt_wait+=(fin_wait-min_time)
            DR[tl_current][day].append((deliv,highest_SOC[1],min_time+(t_prep+t_unpack+extra_wait),fin_deliver))
            B[highest_SOC[1]]['SOC']=(B[highest_SOC[1]]['SOC']-delivery[deliv]['energy'])
            B[highest_SOC[1]]['charger']=None
            t_drocc[tl_current]=fin_deliver
            if len(PQ_d)==0 and len(PQ_ex)==0 and len(PQ_late)==0:
                for drone in DR.keys():
                    finday[drone][day]=t_drocc[drone]

#get minimum time occupied on drone timeline
tl_last=max(t_drocc, key=t_drocc.get)
t_last=t_drocc[tl_last]
h_last=m.floor(t_last/60)
m_last=m.ceil(t_last % 60)

#get delay time
h_wait=m.floor(tt_wait/60)
m_wait=m.ceil(tt_wait % 60)

#===SPARE TIME===========
spare_time={}
total_spare=0
for d in range(day):
    spare_time[d+1]=int(0)
    
for dr in finday.keys():
    for day in finday[dr].keys():
        if finday[dr][day]<day_len:

            spare_time[day]+=(day_len-finday[dr][day])
            
for day in spare_time.keys():
    total_spare+=spare_time[day]
#===SPARE TIME==========

#======REPORT PRINT======================
print('=========SCHEDULE REPORT========')
print('N_DRONES: '+str(N_dr)+'| N_BATTERIES: '+str(N_b)+'| N_CHARGERS: '+str(N_ch))
print('NUMBER OF DELIVERIES: '+str(no_del)+' |VILLAGES: '+str(villages))
print('TOTAL VACCINE VIALS DELIVERED: '+str(total_vials))
print('OXFORD VIALS: '+str(int(vials[0]))+'| J&J VIALS: '+str(int(vials[1]))+'| PFIZER VIALS: '+str(int(vials[2])))
print('Extra deliveries: '+str(day*(m.floor(N_ex/30))))
print('=========TIME STATISTICS========')
print('TIME TAKEN: '+str(day)+' DAYS '+str(h_last)+' HOURS '+str(m_last)+' MINUTES ')
print('WAIT TIME: '+str(h_wait)+' HOURS '+str(m_wait)+' MINUTES '+'| PER DAY: '+str(h_wait/day)+' HOURS ')
print('PARTIAL DAYS: '+str((day-part_days)))
#======REPORT PRINT======================

#======VISUALISATION==================================
plt.rcParams['figure.dpi'] = 200
plt.rcParams['axes.axisbelow'] = True
plt.rcParams["font.family"] = "Cambria"
axes_size=14
title_size=16
subtick_size=8
blue=(0.294,0.533,0.635)
green=(0,0.769,0.604)
yellow=(0.973,0.882,0.424)
red=(1,0,0)
melon=(1,0.761,0.706)
font='Cambria'


#-----DEFINE XLIM, YLIM FOR DRONES AND CHARGERS------
t_day=480
x_div=25

DR_ylim=(N_dr+1)*10
CH_ylim=(N_ch+1)*10

#tick positions
def tickformaty(N):
    linspace=np.linspace(10,N*10,N)
    integers=linspace.astype(int)
    tick_space=integers.tolist()
    tick_label=(tick_space[::-1])
    tick_label = [int(x / 10) for x in tick_label]
    return tick_space,tick_label

def tickformatx(lim,div):
    linspace=np.linspace(0,lim,x_div)
    integers=linspace.astype(int)
    tick_space=integers.tolist()
    return tick_space

x_label=tickformatx(t_day,x_div)
time_tick=['0900','','','1000','','','1100','','','1200','','','1300','','','1400','','','1500','','','1600','','','1700']
for x in range(day):
    day_it=x+1
    plt.figure()
    plt.grid(True)
    plt.ylim(0, CH_ylim)
    plt.xlim(0, t_day)
    plt.title('Charger Schedule Day '+str(day_it),fontsize=title_size)
    plt.xlabel('Time of Day (hrs)', fontsize=axes_size)
    plt.ylabel('Charger Number', fontsize=axes_size)
    ch_tspace, ch_tlabel=tickformaty(N_ch)
    plt.yticks(ch_tspace,ch_tlabel)
    plt.xticks(x_label,time_tick)
    plt.tick_params(axis='both', which='major', labelsize=subtick_size)
    
    for charger in CH.keys():
        for stamp in CH[charger][day_it]: #keys
            CH[charger]['plot']=[]
            CH[charger]['plot'].append((stamp[1],stamp[2]-stamp[1]))
            plt.broken_barh(CH[charger]['plot'], (((N_ch-(charger-1))*10), 2), facecolors =('tab:orange'),edgecolor='black',lw=0.5)
            #uncomment for timestamp annotations
            # plt.annotate((str(stamp[0])+'|'+str(stamp[1])+':'+str(stamp[2])),
            #                   (5, 20),xytext=(stamp[1], ((N_ch-(charger-1))*10)+1),fontsize=4,
            #                   horizontalalignment='left', verticalalignment='top')

    plt.show()

for x in range(day):
    day_it=x+1
    plt.figure()      
    plt.grid(True)
    plt.ylim(0, DR_ylim)
    plt.xlim(0, t_day)
    plt.title('Drone Schedule Day '+str(day_it),fontsize=title_size)
    plt.xlabel('Time of Day (hrs)', fontsize=axes_size)
    plt.ylabel('Drone Number', fontsize=axes_size)
    dr_tspace, dr_tlabel=tickformaty(N_dr)
    plt.yticks(dr_tspace,dr_tlabel)
    plt.xticks(x_label,time_tick)
    plt.tick_params(axis='both', which='major', labelsize=subtick_size)
    
    for drone in DR.keys():
        for stamp in DR[drone][day_it]:
            DR[drone]['plot']=[]
            DR[drone]['plot'].append((stamp[2],stamp[3]-stamp[2]))
            if type(stamp[0])==int:
                if stamp[0] in delivery_extra:
                    plt.broken_barh(DR[drone]['plot'], ((N_dr-(drone-1))*10, 1), color =[green])
                else:
                    plt.broken_barh(DR[drone]['plot'], ((N_dr-(drone-1))*10, 1), color =['b'])
                #uncomment for timestamp annotations
                # plt.annotate((str(stamp[0])+'|B'+str(stamp[1])+'|'+(str(stamp[2])+':'+str(stamp[3]))),
                #               (5, 20),xytext=(stamp[2], ((N_dr-(drone-1))*10)+1),fontsize=4,
                #               horizontalalignment='left', verticalalignment='center')
            elif stamp[0]=='Wait' and (stamp[3]-stamp[2])>20:
                plt.broken_barh(DR[drone]['plot'], (((N_dr-(drone-1))*10), 1), color =[red])
                # plt.annotate(str(stamp[0])+'|'+(str(stamp[2])+':'+str(stamp[3])),
                #               (5, 20),xytext=(stamp[2], ((N_dr-(drone-1))*10)-1),fontsize=4,
                #               horizontalalignment='left', verticalalignment='center')
            elif stamp[0]=='Prep':
                plt.broken_barh(DR[drone]['plot'], (((N_dr-(drone-1))*10), 1), color =['orange'])
                # plt.annotate(str(stamp[0])+'|'+(str(stamp[2])+':'+str(stamp[3])),
                #               (5, 20),xytext=(stamp[2], (N_dr-(drone-1))*10),fontsize=4,
                #               horizontalalignment='left', verticalalignment='center')
    plt.show()