# -*- coding: utf-8 -*-
"""
Created on Sat Apr 24 22:09:53 2021

@author: Alex Luo
"""
#==IMPORT MODULES=====
from __future__ import annotations
from typing import Protocol, Dict, List, Iterator, Tuple, TypeVar, Optional
import pandas as pd
import heapq
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import math as m
from PIL import Image
from scipy import optimize
import scipy as sp


#==GRID CLASSES=====
T = TypeVar('T')
Location = TypeVar('Location')
GridLocation = Tuple[int, int]

class Graph(Protocol):
    def neighbors(self, id: Location) -> List[Location]: pass

class SquareGrid:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.walls: List[GridLocation] = []
    
    def in_bounds(self, id: GridLocation) -> bool:
        (x, y) = id
        return 0 <= x < self.width and 0 <= y < self.height
    
    def passable(self, id: GridLocation) -> bool:
        return id not in self.walls
    
    def neighbors(self, id: GridLocation) -> Iterator[GridLocation]:
        (x, y) = id
        neighbors = [(x+1, y+0), (x+0, y-1), (x-1, y+0), (x+0, y+1), (x-1, y-1), (x-1, y+1), (x+1, y-1), (x+1, y+1)]
        if (x + y) % 2 == 0: neighbors.reverse()
        results = filter(self.in_bounds, neighbors)
        results = filter(self.passable, results)
        return results

class WeightedGraph(Graph):
    def cost(self, from_id: Location, to_id: Location) -> float: pass


class GridWithWeights(SquareGrid):
    def __init__(self, width: int, height: int):
        super().__init__(width, height)
        self.weights: Dict[GridLocation, float] = {}
    
    def cost(self, from_node: GridLocation, to_node: GridLocation) -> float:
        return self.weights.get(to_node, 1)

class PriorityQueue:
    def __init__(self):
        self.elements: List[Tuple[float, T]] = []
    
    def empty(self) -> bool:
        return not self.elements
    
    def put(self, item: T, priority: float):
        heapq.heappush(self.elements, (priority, item))
    
    def get(self) -> T:
        return heapq.heappop(self.elements)[1]

#==A* ROUTING FUNCTIONS=====
def reconstruct_path(came_from: Dict[Location, Location],
                     start: Location, goal: Location) -> List[Location]:
    current: Location = goal
    path: List[Location] = []
    while current != start:
        path.append(current)
        current = came_from[current]
    path.append(start)
    path.reverse()
    return path

def heuristic(a: GridLocation, b: GridLocation) -> float:
    (x1, y1) = a
    (x2, y2) = b
    return abs(x1 - x2) + abs(y1 - y2)

def a_star_search(graph: WeightedGraph, start: Location, goal: Location):
    frontier = PriorityQueue()
    frontier.put(start, 0)
    came_from: Dict[Location, Optional[Location]] = {}
    
    SOC: Dict[Location, float] = {}
    SOC[start]=Q_batt*0.9
    
    cost_so_far: Dict[Location, float] = {}
    cost_so_far[start]=single_cost(start,d_s,SOC,'total')
    
    #==INITIALISING COST DICTIONARIES=====
    C_D_cost: Dict[Location, float] = {}
    C_D_cost[start]=single_cost(start,d_s,SOC,'C_D')
    
    C_data_cost: Dict[Location, float] = {}
    C_data_cost[start]=single_cost(start,d_s,SOC,'C_data')
    
    t_cost: Dict[Location, float] = {}
    t_cost[start]=single_cost(start,d_s,SOC,'t')
    
    C_E_cost: Dict[Location, float] = {}
    C_E_cost[start]=single_cost(start,d_s,SOC,'C_E')
    
    distance: Dict[Location, float] = {}
    distance[start]=0
    
    v_point: Dict[Location, float] = {}
    v_point[start]=cruise_speed(P,v_h[start[1],start[0]])
    
    came_from[start] = None
    
    while not frontier.empty():
        current: Location = frontier.get()
        if current == goal:
            break
        #==LOOPING THROUGH CURRENT NEIGHBOURS=====
        for next in graph.neighbors(current):
            #==SETTING STEP DISTANCE=====
            if (next[0] == current[0]) or (next[1] == current[1]):
                d=d_s
            else:
                d=d_d     
            #==CALCULATING COST OF STEP=====
            v_c=cruise_speed(P,v_h[next[1],next[0]])
            t=time_step(d,v_c)
            C_D,D_bucket,D_temp=degradation_cost(P,t,T_env[next[1],next[0]])
            C_data=data_cost(t)            
            C_E,E_used=energy_cost(P,SOC[current],t)
            new_cost= cost_so_far[current] + C_D + C_data + C_E + t_weight*t
            #==CHECK IF COST IS BETTER THAN PREVIOUS=====
            if next not in cost_so_far or new_cost < cost_so_far[next]:
                #==UPDATING NEIGHBOUT COST=====
                cost_so_far[next] = new_cost
                C_D_cost[next] = C_D_cost[current]+C_D
                C_data_cost[next] = C_data_cost[current]+C_data
                t_cost[next] = t_cost[current]+t_weight*t
                C_E_cost[next] = C_E_cost[current]+C_E
                if SOC[current]-((E_used/E_batt)*Q_batt)<=0:
                    SOC[next]=0.01
                else:
                    SOC[next] = SOC[current]-((E_used/E_batt)*Q_batt)
                distance[next]=distance[current]+d
                v_point[next]=v_c
                priority = new_cost + (10*heuristic(next, goal))
                frontier.put(next, priority)
                came_from[next] = current
        
    return came_from, cost_so_far, SOC, C_D_cost, C_data_cost, t_cost, C_E_cost, distance, v_point

#==IMAGE MAP PROCESSING FUNCTIONS====
#---LOAD IMAGE-------------------------
def load_image(name):
    # load the image
    i_temp = Image.open(name).convert('L')
    # convert image to numpy array
    data = np.asarray(i_temp)
    if len(data)>len(data[0]):
        data = np.delete(data, 0, 0)  # delete second column of C
    if len(data)<len(data[0]):
        data = np.delete(data, 0, 1)
    return data
#---LOAD IMAGE-------------------------

#---SHRINK IMAGE-------------------------
def shrink(datas, rows, cols,v_min,v_max):
    unscaled=datas.reshape(rows, int(datas.shape[0]/rows), cols, int(datas.shape[1]/cols)).sum(axis=1).sum(axis=2)
    shrunk=unscaled/(2800/rows)**2
    rerange=(shrunk/255)*(v_max-v_min)
    formatted=v_max-rerange
    return formatted
#---SHRINK IMAGE-------------------------

#----------------------------------------
def shrink_binary(datas, rows, cols):
    unscaled=datas.reshape(rows, int(datas.shape[0]/rows), cols, int(datas.shape[1]/cols)).sum(axis=1).sum(axis=2)
    unscaled=(unscaled > 150000).astype(int)
    return unscaled
#----------------------------------------


#==SPEED AND TIME FUNCTIONS====
#------v_c-----------
def cruise_speed(P,v_h):
    #thrust calculation
    T=0.73*((3.14/2)*(D**2)*rho*(P**2))**(1/3)
    #velocity calculation
    v_c=0.51*(1-(v_h/25))*m.sqrt(2*m.sqrt(1-(((m_p+m_d)*g)/(25*T))**2)*(T/(rho*c_d*A_e)))
    #maximum speed cap
    if v_c>34:
        v_c=34
    return v_c
#-----v_c------------

#-----t------------
#calculate time for a distance
def time_step(d,v_c):
    t=d/v_c
    return t/3600
#-----t------------

#==COST FUNCTIONS====
#-----C_D------------
def degradation_cost(P,t,T_env):
    D_bucket=((0.3e-5)*P)+((5e-5)*P*t)
    D_temp=D_bucket*m.exp(K_t*(T_env-T_ref)*((T_ref+273)/(T_env+273)))
    C_D=(D_temp/(E_batt*0.2))*batt_cost
    return C_D,D_bucket,D_temp
#-----C_D------------

#------C_data------------
def data_cost(t):
    rate_data=528.2
    C_data=rate_data*t
    return C_data
#------C_data------------

#------C_E------------
def battcurve(x):
    V_lookup=-3.494e-16*(x**5) + 2.114e-12*(x**4) - 4.585e-09*(x**3) + 4.326e-06*(x**2) - 0.002255*x + 3.699
    return V_lookup

def energy_cost(P,Q_soc,t):
    Q_dc=Q_cell-(Q_soc/12)
    I=P/(battcurve(Q_dc*1000)*12)
    E_used=0.9*(E_batt*(I*t/Q_batt))
    C_E=E_used*Wh_rate
    return C_E,E_used
#------C_E------------

#------START COST------------
def single_cost(next,d,SOC,option):
    v_c=cruise_speed(P,v_h[next[1],next[0]])
    t=time_step(d,v_c)
    C_D,D_bucket,D_temp=degradation_cost(P,t,T_env[next[1],next[0]])
    C_data=data_cost(t)    
    statecharge=SOC[next] 
       
    C_E,E_used=energy_cost(P,statecharge,t)
    if option=='C_D':
        return C_D
    if option=='C_data':
        return C_data
    if option=='C_E':
        return C_E
    if option=='t':
        return t_weight*t
    if option=='total':
        return C_D + C_data + C_E + (t_weight*t) 



#==GRID SETUP====
frame=80
diagram4 = GridWithWeights(frame , frame)
diagram4.walls = [(78,48),(74,45)] #military bases

# load temperature, wind and obstacle maps
T_data=load_image('T_map.png')
T_env=shrink(T_data,frame,frame,35,39.5)
w_data=load_image('W_map.png')
v_h=shrink(w_data,frame,frame,3.5,9.5)*0.5
o_data=load_image('O_map.png')
obstacles=1-(shrink_binary(o_data,frame,frame))

# load healthcare facilities
df = pd.read_csv('healthcare_facilities.csv',header=None)
hc=[]
hclong=[]
hclatt=[]
for index, row in df.iterrows():
    hc.append((row[0],row[1]))
    hclong.append(row[0])
    hclatt.append(row[1])

# obstacle creation
for o_row in range(len(obstacles)):
    for o_column in range(len(obstacles[o_row])):
        if obstacles[o_row][o_column]==1:
            diagram4.walls.append((o_column,o_row))

# military premises obstacles
for military in diagram4.walls:
    obstacles[military[1]][military[0]]=1
    
s = (frame,frame)
grid=np.zeros(s)
for wall in diagram4.walls:
    grid[wall[1]][wall[0]]=1
#==GRID SETUP====


#==PARAMETERS====

m_p=1 #Payload weight (kg)
m_d=20 #Drone weight (kg)
g=9.81 #Gravitational acceleration constant (kgm/s^2)
T_ref=25 #Battery reference temperature (degrees)

d_s=2000 #Distance of straight line (m)
d_d=2828 #Distance of diagonal line (m)
K_t=0.0693 #Battery temperature degradation coefficient 

batt_cost=210287 #Battery cost (Naira)
rate_data=528.2 #Data cost (Naira)
Wh_rate=(29/1000) #Energy cost (Naira)
C_zp=23 
t_zp=45
t_weight=0.15*((C_zp/t_zp)*6)*525.72 #Time cost (Naira) 

E_batt=1250 #Battery energy capacity (Wh)
E_real=E_batt*0.9 #Adjusted battery energy capacity (Wh)
Q_cell=2.720 #Cell capacity (Ah) 
Q_batt=28.935 #Battery capacity (Ah) 
 
rho=1.2754 #Density of air (kg/m^3) 
D=0.1 #Rotor diameter (m) 
c_d=0.06 #Drag coefficient 
A_e=0.044461 #Effective area (m^2) 
#==PARAMETERS====


#==JOURNEY OPTIMISATION START====

#create P values to loop through
P_values = np.linspace(300, 750, 20)
#distribution centre coordinates
DC=(40,39)

P_opt_coll={}
for hc_each in hc:
    #creating graph arrays
    plot_total_cost=[]
    plot_degrad_comp=[]
    plot_data_comp=[]
    plot_time_comp=[]
    plot_energy_comp=[]
    plot_total_time=[]
    plot_total_energy=[]
    plot_v_avg=[]
    for P in P_values:
        path=[]
        v_avg=0
        #set start and goal locations
        start, goal = (DC[0], DC[1]), (hc_each[0], hc_each[1])
        #carry out A* route planning
        came_from, cost_so_far, SOC, C_D_cost, C_data_cost, t_cost, C_E_cost, distance, v_point = a_star_search(diagram4, start, goal)
        #store route planning path details
        path=reconstruct_path(came_from, start=start, goal=goal)
        round_cost=int(cost_so_far.get(goal))
        total_cost=cost_so_far.get(goal)
        plot_total_cost.append(round_cost)
        total_time=(t_cost.get(goal))/t_weight
        plot_total_time.append(total_time)
        total_energy=(C_E_cost.get(goal))/Wh_rate
        plot_total_energy.append(total_energy)
        total_distance=distance.get(goal)/1000
        total_degrad=(C_D_cost.get(goal)/batt_cost)*100
        
        SOC_tl={}
        for tl in path:
            SOC_tl[tl]=SOC.get(tl)
        
        #store route planning path details for plotting
        degrad_comp=C_D_cost.get(goal)
        plot_degrad_comp.append(degrad_comp)
        data_comp=C_data_cost.get(goal)
        plot_data_comp.append(data_comp)
        time_comp=t_cost.get(goal)
        plot_time_comp.append( time_comp)
        energy_comp=C_E_cost.get(goal)
        plot_energy_comp.append(energy_comp)
        
        #individual speeds at each step
        for step in path:
            v_avg+=v_point.get(step)
        v_avg=v_avg/len(path)
        plot_v_avg.append(v_avg)
    
    x = P_values
    y = plot_total_cost
    
    #polynomial regression for P values
    mymodel = np.poly1d(np.polyfit(x, y, 7))
    
    def regression(P):
        function=mymodel.coef[0]*(P**7)+mymodel.coef[1]*(P**6)+mymodel.coef[2]*(P**5)+mymodel.coef[3]*(P**4)+mymodel.coef[4]*(P**3)+mymodel.coef[5]*(P**2)+mymodel.coef[6]*(P)+mymodel.coef[7]
        return function
    
    #find minimal point in regression
    solution=sp.optimize.minimize(regression, 450, method='CG')
    P_opt=(solution.x[0])
    print('=====OPTIMAL PARAMETERS for location ('+str(hc_each[0])+','+str(hc_each[1])+ ')=====')
    print('Optimal solution: '+str(P_opt))
    P_opt_coll[goal]=P_opt
    
#==JOURNEY OPTIMISATION END====


#==REPORT DETAILS====
print('=====REPORT=====')
print('POWER: '+str(P)+ ' W')
print('FROM START: '+str(start)+ ' TO GOAL: '+str(goal))
print('Total time: '+str(total_time*60)+ ' mins| Total cost: '+str(total_cost)+ ' N$| Total energy: '+str(total_energy) +' Wh')
print('Battery: '+str((total_energy/E_batt)*100)+ '%')
print('Distance: '+str(total_distance)+ ' km')
print('Average speed: '+str(v_avg)+ ' m/s')
print('Total degradation: '+str(total_degrad)+ ' %')
print('=====COST BREAKDOWN=====')
print('Degrad cost: '+str(degrad_comp)+' N$| '+str((degrad_comp/total_cost)*100)+ '%')
print('Data cost: '+str(data_comp)+' N$| '+str((data_comp/total_cost)*100)+ '%')
print('Time cost: '+str(time_comp) +' N$| '+str((time_comp/total_cost)*100)+ '%')
print('Energy cost: '+str(energy_comp) +' N$| '+str((energy_comp/total_cost)*100)+ '%')
#==REPORT DETAILS====


#==COSTS AT EACH STEP====
dynamic_cost=np.zeros(s)
for key, value in cost_so_far.items():
    dynamic_cost[key[1]][key[0]]=value

#==CREATING DRONE PATH TO PLOT====
x_coords = []
y_coords = []
for coord in path:
    x_coords.append(coord[1])
    y_coords.append(coord[0])

#==GRAPH PLOTTING====
plt.rcParams['figure.dpi'] = 200
axes_size=16
subaxes_size=8
tick_size=100
subtick_size=10
subtitle_size=14

y_degrad_comp = plot_degrad_comp
y_data_comp = plot_data_comp
y_time_comp = plot_time_comp
y_energy_comp = plot_energy_comp

#cost decomposition graph
fig1 = plt.figure(1)
ax1 = fig1.add_subplot(111)
ax1.scatter(x, y,marker = "x", color = "red", s = 50, label='Total cost')
ax1.scatter(x, y_degrad_comp,marker = "x", color = "blue", s = 20, label='Degradation cost')
ax1.scatter(x, y_data_comp, marker = "x", color = "lime", s = 20, label='Data cost')
ax1.scatter(x, y_time_comp,marker = "x", color = "plum", s = 20, label='Time cost')
ax1.scatter(x, y_energy_comp,marker = "x", color = "orange", s = 20, label='Energy cost')
plt.title("Varying drone power with journey cost")
plt.xlabel("Drone Power (W)", fontsize=axes_size)
plt.ylabel("Cost (N$)", fontsize=axes_size)
plt.ylim([0, (max(y)+50)])
plt.legend(loc='upper right',prop={'size': 8})
ax1.tick_params(axis='both', which='major', labelsize=subtick_size)

#total cost graph
fig2 = plt.figure(2)
ax3=fig2.add_subplot(111)
ax3.scatter(x, y,marker = "x", color = "red", s = 50)
plt.title("Varying drone power with total journey cost")
plt.xlabel("Drone Power (W)", fontsize=axes_size)
plt.ylabel("Total cost (\u20a6)", fontsize=axes_size)
plt.ylim([(min(y)-50), (max(y)+50)])
ax3.tick_params(axis='both', which='major', labelsize=subtick_size)

#intermediate variable subplots
fig3 = plt.figure(3)
ax2a = fig3.add_subplot(221)
ax2a.scatter(x, plot_total_time,marker = "x", color = "red", s = 20)
plt.title("Total journey time", fontsize=subtitle_size)
plt.xlabel("Drone Power (W)", fontsize=subaxes_size)
plt.ylabel("Total journey time (h)", fontsize=subaxes_size)
ax2a.tick_params(axis='both', which='major', labelsize=subtick_size)

ax2b = fig3.add_subplot(222)
ax2b.scatter(x, plot_total_energy,marker = "x", color = "red", s = 20)
plt.title("Total energy consumed", fontsize=subtitle_size)
plt.xlabel("Drone Power (W)", fontsize=subaxes_size)
plt.ylabel("Total Energy (Wh)", fontsize=subaxes_size)
ax2b.tick_params(axis='both', which='major', labelsize=subtick_size)

ax2c = fig3.add_subplot(223)
ax2c.scatter(x, plot_v_avg,marker = "x", color = "red", s = 20)
plt.title("Average cruise velocity", fontsize=subtitle_size)
plt.xlabel("Drone Power (W)", fontsize=subaxes_size)
plt.ylabel("Average cruise speed (m/s)", fontsize=subaxes_size)
ax2c.tick_params(axis='both', which='major', labelsize=subtick_size)

fig3.subplots_adjust(left=0.125, bottom=0.1, right=0.9, top=0.9, wspace=0.7, hspace=0.7)
plt.show()

#==GRAPH PLOTTING====


#==DRONE ROUTE VISUALISATION====  
colors = [(1,0,0,c) for c in np.linspace(0,1,100)]
cmapred = mcolors.LinearSegmentedColormap.from_list('mycmap', colors, N=5)

fig, ax = plt.subplots(figsize=(frame,frame))
#uncomment to show temperature, wind, dynamic costs or map
#ax.imshow(T_env, cmap=plt.cm.Greens, alpha=1)
ax.imshow(v_h, cmap=plt.cm.Greens, alpha=1)
#ax.imshow(dynamic_cost, cmap=plt.cm.Greens, alpha=1)
mapping = plt.imread('map_kaduna.png')
#ax.imshow(mapping, zorder=0, extent = (0,80,80,0), aspect= 'equal')
ax.imshow(obstacles, cmap=cmapred)
ax.scatter(start[0],start[1], marker = "*", color = "red", s = 5000)
ax.scatter(goal[0],goal[1], marker = "*", color = "cyan", s = 2000)
ax.scatter(hclong,hclatt, marker = "*", color = "orange", s = 2000)
ax.plot(y_coords,x_coords, color = "black", linewidth=4)
ax.tick_params(axis='both', which='major', labelsize=tick_size)
plt.show()
#==DRONE ROUTE VISUALISATION====