# -*- coding: utf-8 -*-
"""
Created on Sat Apr 24 22:09:53 2021

@author: Alex Luo
"""
from __future__ import annotations
from typing import Protocol, Dict, List, Iterator, Tuple, TypeVar, Optional
import pandas as pd
import heapq
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import math as m
from PIL import Image


#==GRID CLASSES=====
T = TypeVar('T')
Location = TypeVar('Location')
GridLocation = Tuple[int, int]

class Graph(Protocol):
    def neighbors(self, id: Location) -> List[Location]: pass

class SquareGrid:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.walls: List[GridLocation] = []
    
    def in_bounds(self, id: GridLocation) -> bool:
        (x, y) = id
        return 0 <= x < self.width and 0 <= y < self.height
    
    def passable(self, id: GridLocation) -> bool:
        return id not in self.walls
    
    def neighbors(self, id: GridLocation) -> Iterator[GridLocation]:
        (x, y) = id
        neighbors = [(x+1, y+0), (x+0, y-1), (x-1, y+0), (x+0, y+1), (x-1, y-1), (x-1, y+1), (x+1, y-1), (x+1, y+1)]
        if (x + y) % 2 == 0: neighbors.reverse()
        results = filter(self.in_bounds, neighbors)
        results = filter(self.passable, results)
        return results

class WeightedGraph(Graph):
    def cost(self, from_id: Location, to_id: Location) -> float: pass


class GridWithWeights(SquareGrid):
    def __init__(self, width: int, height: int):
        super().__init__(width, height)
        self.weights: Dict[GridLocation, float] = {}
    
    def cost(self, from_node: GridLocation, to_node: GridLocation) -> float:
        return self.weights.get(to_node, 1)

class PriorityQueue:
    def __init__(self):
        self.elements: List[Tuple[float, T]] = []
    
    def empty(self) -> bool:
        return not self.elements
    
    def put(self, item: T, priority: float):
        heapq.heappush(self.elements, (priority, item))
    
    def get(self) -> T:
        return heapq.heappop(self.elements)[1]

#==A* ROUTING FUNCTIONS=====
def reconstruct_path(came_from: Dict[Location, Location],
                     start: Location, goal: Location) -> List[Location]:
    current: Location = goal
    path: List[Location] = []
    while current != start:
        path.append(current)
        current = came_from[current]
    path.append(start)
    path.reverse()
    return path


def heuristic(a: GridLocation, b: GridLocation) -> float:
    (x1, y1) = a
    (x2, y2) = b
    return abs(x1 - x2) + abs(y1 - y2)

def a_star_search(graph: WeightedGraph, start: Location, goal: Location):
    frontier = PriorityQueue()
    frontier.put(start, 0)
    came_from: Dict[Location, Optional[Location]] = {}
    
    SOC: Dict[Location, float] = {}
    SOC[start]=Q_batt*0.9
    
    cost_so_far: Dict[Location, float] = {}
    cost_so_far[start]=single_cost(start,d_s,SOC,'total')
    
    #==INITIALISING COST DICTIONARIES=====
    C_D_cost: Dict[Location, float] = {}
    C_D_cost[start]=single_cost(start,d_s,SOC,'C_D')
    
    C_data_cost: Dict[Location, float] = {}
    C_data_cost[start]=single_cost(start,d_s,SOC,'C_data')
    
    t_cost: Dict[Location, float] = {}
    t_cost[start]=single_cost(start,d_s,SOC,'t')
    
    C_E_cost: Dict[Location, float] = {}
    C_E_cost[start]=single_cost(start,d_s,SOC,'C_E')
    
    distance: Dict[Location, float] = {}
    distance[start]=0
    
    v_point: Dict[Location, float] = {}
    v_point[start]=cruise_speed(P,v_h[start[1],start[0]])
    
    came_from[start] = None
    
    while not frontier.empty():
        current: Location = frontier.get()
        if current == goal:
            break
        #==LOOPING THROUGH CURRENT NEIGHBOURS=====
        for next in graph.neighbors(current):
            #==SETTING STEP DISTANCE=====
            if (next[0] == current[0]) or (next[1] == current[1]):
                d=d_s
            else:
                d=d_d  
            #==CALCULATING COST OF STEP=====
            v_c=cruise_speed(P,v_h[next[1],next[0]])
            t=time_step(d,v_c)
            C_D,D_bucket,D_temp=degradation_cost(P,t,T_env[next[1],next[0]])
            C_data=data_cost(t)            
            C_E,E_used=energy_cost(P,SOC[current],t)
            new_cost= cost_so_far[current] + C_D + C_data + C_E + t_weight*t
            #==CHECK IF COST IS BETTER THAN PREVIOUS=====
            if next not in cost_so_far or new_cost < cost_so_far[next]:
                #==UPDATING NEIGHBOUT COST=====                
                cost_so_far[next] = new_cost
                C_D_cost[next] = C_D_cost[current]+C_D
                C_data_cost[next] = C_data_cost[current]+C_data
                t_cost[next] = t_cost[current]+t_weight*t
                C_E_cost[next] = C_E_cost[current]+C_E
                if SOC[current]-((E_used/E_batt)*Q_batt)<=0:
                    SOC[next]=0.01
                else:
                    SOC[next] = SOC[current]-((E_used/E_batt)*Q_batt)
                distance[next]=distance[current]+d
                v_point[next]=v_c
                priority = new_cost + (10*heuristic(next, goal))
                frontier.put(next, priority)
                came_from[next] = current
        
    return came_from, cost_so_far, SOC, C_D_cost, C_data_cost, t_cost, C_E_cost, distance, v_point

#==IMAGE MAP PROCESSING FUNCTIONS====
#---LOAD IMAGE-------------------------
def load_image(name):
    # load the image
    i_temp = Image.open(name).convert('L')
    # convert image to numpy array
    data = np.asarray(i_temp)
    if len(data)>len(data[0]):
        data = np.delete(data, 0, 0)  # delete second column of C
    if len(data)<len(data[0]):
        data = np.delete(data, 0, 1)
    return data
#---LOAD IMAGE-------------------------

#---SHRINK IMAGE-------------------------
def shrink(datas, rows, cols,v_min,v_max):
    unscaled=datas.reshape(rows, int(datas.shape[0]/rows), cols, int(datas.shape[1]/cols)).sum(axis=1).sum(axis=2)
    shrunk=unscaled/(2800/rows)**2
    rerange=(shrunk/255)*(v_max-v_min)
    formatted=v_max-rerange
    return formatted
#---SHRINK IMAGE-------------------------

#----------------------------------------
def shrink_binary(datas, rows, cols):
    unscaled=datas.reshape(rows, int(datas.shape[0]/rows), cols, int(datas.shape[1]/cols)).sum(axis=1).sum(axis=2)
    unscaled=(unscaled > 150000).astype(int)
    
    return unscaled
#----------------------------------------


#==SPEED AND TIME FUNCTIONS====
#------v_c-----------
def cruise_speed(P,v_h):
    T=0.73*((3.14/2)*(D**2)*rho*(P**2))**(1/3)
    v_c=0.51*(1-(v_h/25))*m.sqrt(2*m.sqrt(1-(((m_p+m_d)*g)/(25*T))**2)*(T/(rho*c_d*A_e)))
    if v_c>34:
        v_c=34
        
    return v_c
#-----v_c------------

#-----t------------
def time_step(d,v_c):
    t=d/v_c
    return t/3600
#-----t------------

#-----C_D------------
def degradation_cost(P,t,T_env):
    D_bucket=((0.3e-5)*P)+((5e-5)*P*t)
    D_temp=D_bucket*m.exp(K_t*(T_env-T_ref)*((T_ref+273)/(T_env+273)))
    C_D=(D_temp/(E_batt*0.2))*batt_cost
    return C_D,D_bucket,D_temp
#-----C_D------------

#------C_data------------
def data_cost(t):
    rate_data=528.2
    C_data=rate_data*t
    return C_data
#------C_data------------

#------C_E------------
def battcurve(x):
    V_lookup=-3.494e-16*(x**5) + 2.114e-12*(x**4) - 4.585e-09*(x**3) + 4.326e-06*(x**2) - 0.002255*x + 3.699
    return V_lookup

def energy_cost(P,Q_soc,t):
    Q_dc=Q_cell-(Q_soc/12)
    I=P/(battcurve(Q_dc*1000)*12)
    E_used=0.9*(E_batt*(I*t/Q_batt))
    C_E=E_used*Wh_rate
    return C_E,E_used
#------C_E------------

#------START COST------------
def single_cost(next,d,SOC,option):
    v_c=cruise_speed(P,v_h[next[1],next[0]])
    t=time_step(d,v_c)
    C_D,D_bucket,D_temp=degradation_cost(P,t,T_env[next[1],next[0]])
    C_data=data_cost(t)    
    statecharge=SOC[next] 
    C_E,E_used=energy_cost(P,statecharge,t)

    if option=='C_D':
        return C_D
    if option=='C_data':
        return C_data
    if option=='C_E':
        return C_E
    if option=='t':
        return t_weight*t
    if option=='total':
        return C_D + C_data + C_E + (t_weight*t) 

#--------------------------------------

def add_values_in_dict(sample_dict, key, list_of_values):
    if key not in sample_dict:
        sample_dict[key] = list()
    sample_dict[key].extend(list_of_values)
    return sample_dict


#GRID SETUP----------------------------
frame=80
diagram4 = GridWithWeights(frame , frame)
diagram4.walls = [(78,48),(74,45)] #military bases


T_data=load_image('T_map.png')
T_env=shrink(T_data,frame,frame,35,39.5)
w_data=load_image('W_map.png')
v_h=shrink(w_data,frame,frame,3.5,9.5)*0.5
o_data=load_image('O_map.png')
obstacles=1-(shrink_binary(o_data,frame,frame))

# load healthcare facilities
df = pd.read_csv('healthcare_facilities.csv',header=None)
hc=[]
hclong=[]
hclatt=[]
for index, row in df.iterrows():
    hc.append((row[0],row[1]))
    hclong.append(row[0])
    hclatt.append(row[1])


for o_row in range(len(obstacles)):
    for o_column in range(len(obstacles[o_row])):
        if obstacles[o_row][o_column]==1:
            diagram4.walls.append((o_column,o_row))

for military in diagram4.walls:
    obstacles[military[1]][military[0]]=1
    

s = (frame,frame)
grid=np.zeros(s)
for wall in diagram4.walls:
    grid[wall[1]][wall[0]]=1
#Grid setup----------------------------


#==PARAMETERS====

m_p=1 #Payload weight (kg)
m_d=20 #Drone weight (kg)
g=9.81 #Gravitational acceleration constant (kgm/s^2)
T_ref=25 #Battery reference temperature (degrees)

d_s=2000 #Distance of straight line (m)
d_d=2828 #Distance of diagonal line (m)
K_t=0.0693 #Battery temperature degradation coefficient 

batt_cost=210287 #Battery cost (Naira)
rate_data=528.2 #Data cost (Naira)
Wh_rate=(29/1000) #Energy cost (Naira)
C_zp=23 
t_zp=45
t_weight=0.15*((C_zp/t_zp)*6)*525.72 #Time cost (Naira) 

E_batt=1250 #Battery energy capacity (Wh)
E_real=E_batt*0.9 #Adjusted battery energy capacity (Wh)
Q_cell=2.720 #Cell capacity (Ah) 
Q_batt=28.935 #Battery capacity (Ah) 
 
rho=1.2754 #Density of air (kg/m^3) 
D=0.1 #Rotor diameter (m) 
c_d=0.06 #Drag coefficient 
A_e=0.044461 #Effective area (m^2) 
#==PARAMETERS====


#==JOURNEY OPTIMISATION START====
N_d=94
P_nopt={}
for i in range(94):
    P_nopt[i+1]=390

DC=(40,39)

plot_total_cost=[]
plot_degrad_comp=[]
plot_data_comp=[]
plot_time_comp=[]
plot_energy_comp=[]
plot_total_time=[]
plot_total_energy=[]
plot_v_avg=[]
#import optimised vaues from previos drone route optimisation
P_opt_coll= {(5.0, 50.0): 519.109375, (6.0, 49.0): 507.44140625, (8.0, 37.0): 517.734375, (8.0, 46.0): 520.2679872761094, (9.0, 43.0): 517.95703125, (9.0, 57.0): 523.4092906142193, (10.0, 40.0): 524.6285564376522, (10.0, 49.0): 522.9678141423187, (11.0, 43.0): 512.421875, (14.0, 49.0): 519.1601562497116, (15.0, 47.0): 526.2802210133933, (19.0, 43.0): 525.9969286593519, (25.0, 46.0): 527.8185364758465, (27.0, 44.0): 530.8324161626091, (28.0, 43.0): 524.82421875, (29.0, 43.0): 528.6503906218096, (29.0, 44.0): 531.31640625, (30.0, 45.0): 544.908984375, (30.0, 24.0): 535.4434327927286, (30.0, 44.0): 530.587890625, (32.0, 40.0): 534.181780275623, (33.0, 40.0): 530.3320111242633, (34.0, 43.0): 504.61328125, (36.0, 40.0): 530.5, (39.0, 39.0): 525.31689453125, (40.0, 39.0): 525.7058919270834, (40.0, 28.0): 535.8842498210532, (41.0, 12.0): 533.0, (42.0, 9.0): 526.64453125, (42.0, 19.0): 528.3259477459017, (48.0, 21.0): 533.6731177488974, (48.0, 12.0): 531.0546875, (50.0, 45.0): 542.6201822916667, (50.0, 13.0): 533.078125, (51.0, 11.0): 531.8906227038111, (52.0, 10.0): 533.4765625, (52.0, 12.0): 538.9232674679612, (53.0, 22.0): 541.0000000016205, (54.0, 6.0): 541.5473958333333, (54.0, 18.0): 536.13669642452, (54.0, 7.0): 534.50390625, (55.0, 19.0): 539.9725531511077, (56.0, 66.0): 527.62109375, (56.0, 44.0): 537.0102457929946, (56.0, 21.0): 537.5868248242875, (57.0, 15.0): 541.66171875, (57.0, 22.0): 536.65625, (58.0, 22.0): 538.4363839285714, (59.0, 18.0): 540.4911256129662, (60.0, 26.0): 531.4204545376657, (61.0, 18.0): 540.1921869472012, (61.0, 22.0): 529.0, (62.0, 26.0): 528.6481481481482, (63.0, 30.0): 525.1379206730769, (64.0, 21.0): 531.8710729848017, (65.0, 16.0): 534.8425741803568, (65.0, 48.0): 522.80859375, (65.0, 53.0): 535.42578125, (66.0, 49.0): 533.7703125, (66.0, 66.0): 544.2625868055555, (66.0, 14.0): 536.2332298530179, (66.0, 19.0): 534.9669298782653, (66.0, 45.0): 532.5, (67.0, 45.0): 522.5, (67.0, 17.0): 528.53515625, (67.0, 60.0): 538.1760555171936, (67.0, 20.0): 527.7109375, (68.0, 50.0): 526.40078125, (68.0, 45.0): 518.0, (68.0, 15.0): 535.9694228337946, (70.0, 20.0): 521.8719951923077, (70.0, 41.0): 526.3046875, (70.0, 64.0): 536.98828125, (71.0, 35.0): 526.53125, (71.0, 18.0): 531.7651187984926, (72.0, 21.0): 529.7830407611003, (73.0, 42.0): 527.394295064984, (77.0, 26.0): 528.40625, (78.0, 37.0): 523.046875, (57.0, 38.0): 527.3213941376016, (36.0, 36.0): 534.7227939581122, (57.0, 52.0): 540.481399571257, (44.0, 34.0): 523.8777374751984, (35.0, 31.0): 535.0387088034465, (24.0, 30.0): 529.0804986197751, (67.0, 61.0): 543.1250000021986, (73.0, 48.0): 521.2877604166666, (72.0, 27.0): 525.7057291666666, (47.0, 42.0): 536.6232717112777, (64.0, 66.0): 531.8643973214283, (25.0, 40.0): 532.2937259931932, (42.0, 30.0): 521.41328125, (54.0, 23.0): 539.4258556385329, (70.0, 32.0): 527.845719188093}
opt_path={}
journey_number=1
for hc_each in P_opt_coll.keys():
    P=P_opt_coll[hc_each]
    print ('ROUND: '+ str(P_opt_coll[hc_each])+ ' W')
    print ('LOCATION: '+ str(hc_each))
    v_avg=0
    start, goal = ((DC[0], DC[1]),(int(hc_each[0]), int(hc_each[1])))
    came_from, cost_so_far, SOC, C_D_cost, C_data_cost, t_cost, C_E_cost, distance, v_point = a_star_search(diagram4, start, goal)
    
    opt_path=add_values_in_dict(opt_path, hc_each, reconstruct_path(came_from, start=start, goal=goal))
    round_cost=int(cost_so_far.get(goal))
    total_cost=cost_so_far.get(goal)
    plot_total_cost.append(round_cost) 
    total_time=(t_cost.get(goal))/t_weight
    plot_total_time.append(total_time)
    total_energy=(C_E_cost.get(goal))/Wh_rate
    plot_total_energy.append(total_energy)
    total_distance=distance.get(goal)/1000
    total_degrad=(C_D_cost.get(goal)/batt_cost)*100
    
    
    #cost breakdown
    degrad_comp=C_D_cost.get(goal)
    plot_degrad_comp.append(degrad_comp)
    data_comp=C_data_cost.get(goal)
    plot_data_comp.append(data_comp)
    time_comp=t_cost.get(goal)
    plot_time_comp.append( time_comp)
    energy_comp=C_E_cost.get(goal)
    plot_energy_comp.append(energy_comp)
    
    #individual speeds
    for v_key, v_val in opt_path.items():
        if v_key==hc_each:
            for step in v_val:
                v_avg+=v_point.get(step)
        
    v_avg=v_avg/len(opt_path[hc_each])
    plot_v_avg.append(v_avg)
    
    # x = P_values
    # y = plot_total_cost
    
    outFileName="C:\\Users\\Alison Luo\\OneDrive - Imperial College London\\Documents\\Documents\\DE4\\Solo project\\Optimisation\\Journey\\Reports\\"+ "Optimised_delivery_results" + ".txt"
    
    file=open(outFileName,"a")
    
    # file.write('=====REPORT===== \n')
    # file.write(f'POWER: {P_opt_coll[hc_each]}  W \n')
    # file.write(f'FROM START: {start} TO GOAL: {goal}\n')
    # file.write(f'Total time:{total_time*60} mins| Total cost: {total_cost} N$| Total energy: {total_energy} Wh \n')
    # file.write(f'Battery: {(total_energy/E_batt)*100} % \n')
    # file.write(f'Distance: {total_distance} km \n')
    # file.write(f'Average speed: {v_avg} m/s \n')
    # file.write(f'Total degradation: {total_degrad} % \n')
    # file.write('=====COST BREAKDOWN===== \n')
    # file.write(f'Degrad cost: {degrad_comp} N$| {(degrad_comp/total_cost)*100} % \n')
    # file.write(f'Data cost: {data_comp} N$| {(data_comp/total_cost)*100} % \n')
    # file.write(f'Time cost: {time_comp} N$| {(time_comp/total_cost)*100} % \n')
    # file.write(f'Energy cost: {energy_comp} N$| {(energy_comp/total_cost)*100} % \n')
    # file.write('  \n')
    # file.close()
    
    file.write(f'=====REPORT {journey_number} Goal: {goal}=====\n')
    file.write(f'{journey_number}\n')
    file.write(f'{start[0]} {start[1]} {goal[0]} {goal[1]}\n')
    file.write(f'{total_time*60}\n')
    file.write(f'{(total_energy/E_batt)*100}\n')
    file.write(f'{total_distance}\n')
    file.write(f'{total_cost}\n')
    file.write('=====END===== \n')
    file.close()
    
    journey_number+=1

#Journey done----------------------------


#==DRONE ROUTE VISUALISATION==== 
plt.rcParams['figure.dpi'] = 200
axes_size=16
subaxes_size=8
tick_size=100
subtick_size=10
subtitle_size=14
  
colors = [(1,0,0,c) for c in np.linspace(0,1,100)]
cmapred = mcolors.LinearSegmentedColormap.from_list('mycmap', colors, N=5)

fig, ax = plt.subplots(figsize=(frame,frame))
#ax.imshow(T_env, cmap=plt.cm.Greens, alpha=1)#!**
#ax.imshow(v_h, cmap=plt.cm.Greens, alpha=1)
#ax.imshow(dynamic_cost, cmap=plt.cm.Greens, alpha=1)
mapping = plt.imread('map_kaduna.png')
ax.imshow(mapping, zorder=0, extent = (0,80,80,0), aspect= 'equal')
ax.imshow(obstacles, cmap=cmapred)
ax.scatter(start[0],start[1], marker = "*", color = "red", s = 5000)
#ax.scatter(goal[0],goal[1], marker = "*", color = "cyan", s = 2000)
ax.scatter(hclong,hclatt, marker = "*", color = "orange", s = 2000)

for key, values in opt_path.items():
    x_coords = []
    y_coords = []
    for pinpoint in values:
        x_coords.append(pinpoint[0])
        y_coords.append(pinpoint[1])
    ax.plot(x_coords,y_coords, color = "black", linewidth=4)
    
ax.tick_params(axis='both', which='major', labelsize=tick_size)
plt.show()
#==DRONE ROUTE VISUALISATION====  